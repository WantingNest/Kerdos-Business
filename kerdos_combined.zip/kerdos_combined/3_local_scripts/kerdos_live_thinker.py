#!/usr/bin/env python3
import datetime
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import warnings
from html.parser import HTMLParser

warnings.filterwarnings("ignore", category=RuntimeWarning)

try:
    import ollama
except ImportError:
    print("The 'ollama' Python library is not installed.")
    print("Install it with:  pip install ollama ddgs")
    sys.exit(1)

DDGS = None
SEARCH_PACKAGE = ""
try:
    from ddgs import DDGS
    SEARCH_PACKAGE = "ddgs"
except ImportError:
    try:
        from duckduckgo_search import DDGS
        SEARCH_PACKAGE = "duckduckgo_search"
    except ImportError:
        DDGS = None

MODEL = os.environ.get("KERDOS_MODEL", "llama3")
CONTEXT_SIZE = 8192
TEMPERATURE = 0.7
IDEAS_MIN_ANSWERS = 6
OVERLAP_LIMIT = 10
MAX_ROUNDS = 3
RESULTS_PER_QUERY = 5
PAGES_TO_READ = 6
FETCH_TIMEOUT = 8
MAX_BYTES = 400000
MAX_TEXT = 12000
SEARCH_PAUSE = 1.0
HEAVY_PAGE_SCORE = 30
HEAVY_PAGE_COUNT = 3

SYSTEM_PROMPT = """You are an advanced, independent AI Business Strategist. Your purpose is to collaborate with the user to discover a tailored business idea, target job role, and industry genre.
Core Rules:
- NO FIXED QUESTION TEMPLATES: You are strictly forbidden from using pre-scripted, quiz-like, or templated questions. Every question must be fully organic, custom-built in real-time, and adaptive based strictly on what information is logically missing.
- ONE QUESTION PER TURN: Keep the user experience conversational. Never ask multiple questions at once. Ask one tailored question, wait for the response, and adapt.
- ABSOLUTE SLANG & CONTEXT FLUENCY: You have native comprehension of modern internet culture and slang (e.g., 'doom scrolling', 'brain rot'). You must NEVER interpret slang as a literal product or business asset. If a user names a habit like 'doom scrolling,' your next question must dynamically address that behavioral ecosystem (e.g., attention algorithms, digital fatigue) as a source for discovery.
- IDEATION CONSTRAINTS: Unless the user explicitly selects 'Yes' to an early concept on the very first question, any final business idea you generate must be a completely novel synthesis with a maximum 10% market overlap against real-world companies. All finalized business models must structurally include Kerdos's tiered pricing framework: a $100/year subscription and a $300 premium lifetime access plan."""

KICKOFF = (
    "Begin the interview now. Greet me in one short sentence, then ask your first question: "
    "whether I want to enter a market that already has existing business competition. "
    "Ask only that one question."
)

HELP_TEXT = """Commands:
  /check   run the live web competition check on the idea in the last reply
  /save    save this conversation and every web check report to a text file
  /reset   start a brand new interview
  /help    show this list
  /quit    leave (Ctrl+C also works)

The web check also runs by itself whenever the strategist presents a concrete business idea."""

METHOD_NOTE = (
    "How the overlap number is calculated: the idea is broken into 10 distinctive features. "
    "The script reads the real pages found by DuckDuckGo and counts how many features appear on a single page. "
    "Pages that look like products or services (pricing, sign up, subscribe) count fully; other pages count half. "
    "The highest page score is the market overlap. This is keyword matching on live pages, not a legal or market study."
)

PRODUCT_CUES = (
    "pricing", "sign up", "signup", "subscribe", "free trial", "get started", "plans", "buy now",
    "download", "log in", "login", "per month", "/month", "add to cart", "book a demo", "join now",
)

YES_WORDS = ("yes", "y", "yeah", "yep", "yup", "sure", "absolutely", "definitely")


class TextExtractor(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.skip = 0
        self.parts = []
        self.title = ""
        self.meta = ""
        self.in_title = False

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style", "noscript", "svg"):
            self.skip += 1
        elif tag == "title":
            self.in_title = True
        elif tag == "meta":
            info = dict(attrs)
            name = (info.get("name") or info.get("property") or "").lower()
            if name in ("description", "og:description"):
                self.meta += " " + (info.get("content") or "")

    def handle_endtag(self, tag):
        if tag in ("script", "style", "noscript", "svg") and self.skip > 0:
            self.skip -= 1
        elif tag == "title":
            self.in_title = False

    def handle_data(self, data):
        if self.skip:
            return
        if self.in_title:
            self.title += data
        else:
            self.parts.append(data)


def short(value, size=90):
    text = str(value).replace("\n", " ").strip()
    return text if len(text) <= size else text[: size - 1] + "~"


def parse_json(text):
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end < start:
        return None
    try:
        return json.loads(text[start : end + 1])
    except ValueError:
        return None


def model_name(entry):
    try:
        return entry["model"]
    except Exception:
        pass
    try:
        return entry["name"]
    except Exception:
        return str(getattr(entry, "model", ""))


def check_ollama():
    try:
        response = ollama.list()
    except Exception as err:
        print("Could not reach Ollama on this computer.")
        print("Start the Ollama app (or run 'ollama serve' in another window) and try again.")
        print("Details: " + str(err))
        return False
    try:
        models = response["models"]
    except Exception:
        models = getattr(response, "models", [])
    names = [model_name(m) for m in models]
    if not any(n.startswith(MODEL) for n in names):
        print("The model '" + MODEL + "' is not downloaded yet.")
        print("Download it with:  ollama pull " + MODEL)
        return False
    return True


def web_search(query):
    try:
        with DDGS() as client:
            rows = client.text(query, max_results=RESULTS_PER_QUERY)
    except Exception as err:
        print("      (search failed: " + short(err, 70) + ")")
        return []
    results = []
    for row in rows or []:
        url = row.get("href") or row.get("url") or ""
        if url.startswith("http"):
            results.append({"title": row.get("title", ""), "url": url, "snippet": row.get("body", "")})
    return results


def fetch_page(url):
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0 (compatible; KerdosThinker/1.0; local research tool)", "Accept": "text/html"},
    )
    try:
        with urllib.request.urlopen(request, timeout=FETCH_TIMEOUT) as response:
            if "html" not in response.headers.get("Content-Type", "").lower():
                return None
            raw = response.read(MAX_BYTES)
            charset = response.headers.get_content_charset() or "utf-8"
    except Exception:
        return None
    parser = TextExtractor()
    try:
        parser.feed(raw.decode(charset, errors="replace"))
    except Exception:
        pass
    body = " ".join(" ".join(parser.parts).split())
    return {"title": " ".join(parser.title.split()), "text": (parser.title + " " + parser.meta + " " + body)[:MAX_TEXT]}


def has_term(text, term):
    term = term.strip().lower()
    if len(term) < 3:
        return False
    return re.search(r"\b" + re.escape(term) + r"\b", text) is not None


def is_commercial(text):
    hits = 0
    for cue in PRODUCT_CUES:
        if cue in text:
            hits += 1
    return hits >= 2


def clean_idea(raw):
    def text(key):
        return str(raw.get(key, "")).strip()

    queries = raw.get("queries", [])
    if not isinstance(queries, list):
        queries = []
    features = []
    for item in raw.get("features", []) if isinstance(raw.get("features"), list) else []:
        if not isinstance(item, dict):
            continue
        words = item.get("keywords", [])
        if not isinstance(words, list):
            continue
        words = [str(w).strip().lower() for w in words if len(str(w).strip()) >= 3]
        if words:
            features.append({"label": str(item.get("label", words[0])).strip(), "keywords": words[:3]})
    return {
        "name": text("name"),
        "pitch": text("pitch"),
        "audience": text("audience"),
        "problem": text("problem"),
        "method": text("method"),
        "queries": [str(q).strip() for q in queries if str(q).strip()][:3],
        "features": features[:12],
    }


class KerdosInterview:
    def __init__(self):
        self.reset()

    def reset(self):
        self.history = [{"role": "system", "content": SYSTEM_PROMPT}]
        self.user_turns = 0
        self.correction = ""
        self.competition_ok = False
        self.checked = set()
        self.reports = []
        self.last_reply = ""

    def options(self):
        return {"num_ctx": CONTEXT_SIZE, "temperature": TEMPERATURE}

    def build_reminder(self):
        lines = [
            "Reminder for this turn: follow every Core Rule in your instructions.",
            "Ask at most one question, with exactly one question mark. Never use a quiz-style or scripted question.",
            "Read slang by its behavioral meaning, never as a literal product or asset.",
            "Remember everything the user has told you in this conversation and build on it.",
        ]
        if self.user_turns < IDEAS_MIN_ANSWERS:
            lines.append("Do not suggest any business ideas yet. You have only had " + str(self.user_turns) + " answers. Keep learning about their job role or skills, the genre they want, real problems they have seen, a secondary interest, their weekly hours, and their budget.")
        else:
            lines.append("If you already know their job role or skills, the genre, a real problem, a secondary interest, weekly hours, and budget, present exactly ONE concrete business idea: its name, a one-sentence pitch, the audience, the problem, and the method. A script will check it against live web pages and report back, so do not claim any overlap number yourself. Otherwise ask exactly one question about what is missing.")
        if self.correction:
            lines.append(self.correction)
        return "\n".join(lines)

    def stream_reply(self, reminder):
        messages = self.history + [{"role": "system", "content": reminder}]
        parts = []
        print("\nStrategist: ", end="", flush=True)
        try:
            for chunk in ollama.chat(model=MODEL, messages=messages, stream=True, options=self.options()):
                piece = chunk["message"]["content"]
                parts.append(piece)
                print(piece, end="", flush=True)
        except KeyboardInterrupt:
            print("\n(Cancelled.)")
            return None
        except Exception as err:
            print("\n\nSomething went wrong talking to Ollama: " + str(err))
            print("Check that the Ollama app is running, then try again.")
            return None
        print()
        reply = "".join(parts).strip()
        self.history.append({"role": "assistant", "content": reply})
        self.last_reply = reply
        return reply

    def send(self, user_text, count_turn=True):
        first_real_answer = count_turn and self.user_turns == 0
        self.history.append({"role": "user", "content": user_text})
        reply = self.stream_reply(self.build_reminder())
        if reply is None:
            self.history.pop()
            return
        self.correction = ""
        if first_real_answer:
            first_word = user_text.strip().lower().split(" ")[0].strip(".,!?")
            self.competition_ok = first_word in YES_WORDS
        if count_turn:
            self.user_turns += 1
        if reply.count("?") > 1:
            self.correction = "Your previous reply asked more than one question. From now on ask exactly one question."
        if self.user_turns >= IDEAS_MIN_ANSWERS and (len(reply) >= 220 or "$100" in reply):
            self.try_check(reply, forced=False)

    def chat_json(self, prompt):
        messages = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": prompt}]
        try:
            response = ollama.chat(model=MODEL, messages=messages, stream=False, format="json", options=self.options())
            return parse_json(response["message"]["content"])
        except KeyboardInterrupt:
            raise
        except Exception as err:
            print("   (the model call failed: " + short(err, 80) + ")")
            return None

    def extract_idea(self, reply):
        prompt = (
            "Read the assistant message below. Decide whether it proposes a concrete business idea (a named or clearly described product or service), as opposed to only asking a question.\n"
            "Return ONLY a JSON object: "
            '{"is_idea": true, "idea": {"name": "", "pitch": "", "audience": "", "problem": "", "method": "", '
            '"queries": ["three different web search queries a person would use to find existing competitors", "", ""], '
            '"features": [{"label": "short feature name", "keywords": ["a specific word or short phrase a competitor page would use", ""]}]}}\n'
            "If it is not a concrete idea, return {\"is_idea\": false}.\n"
            "Features: give exactly 10 distinctive features of THIS idea. Do not use generic words like app, platform, subscription, or service as keywords. Each keywords list has 1 to 3 specific terms.\n\n"
            "Assistant message:\n" + reply
        )
        data = self.chat_json(prompt)
        if not data or not data.get("is_idea") or not isinstance(data.get("idea"), dict):
            return None
        idea = clean_idea(data["idea"])
        if not idea["name"] or len(idea["features"]) < 5:
            return None
        return idea

    def try_check(self, reply, forced):
        try:
            print("\n[Kerdos] Looking for a concrete idea in that reply")
            idea = self.extract_idea(reply)
            if not idea:
                if forced:
                    print("[Kerdos] I could not find a concrete idea to check in the last reply.")
                return
            key = idea["name"].lower()
            if key in self.checked and not forced:
                return
            self.checked.add(key)
            self.check_loop(idea)
        except KeyboardInterrupt:
            print("\n[Kerdos] Web check cancelled.")

    def web_check(self, idea):
        queries = list(idea["queries"])
        queries.append(short(idea["method"] + " " + idea["audience"], 80))
        seen = []
        for q in queries:
            if q and q not in seen:
                seen.append(q)
        per_query = []
        for q in seen[:4]:
            print("   searching: " + short(q, 70))
            per_query.append(web_search(q))
            time.sleep(SEARCH_PAUSE)
        ordered = []
        used_hosts = set()
        longest = max([len(r) for r in per_query] + [0])
        for rank in range(longest):
            for results in per_query:
                if rank < len(results):
                    row = results[rank]
                    host = urllib.parse.urlparse(row["url"]).netloc.lower().replace("www.", "")
                    if host and host not in used_hosts:
                        used_hosts.add(host)
                        ordered.append(row)
        ordered = ordered[:PAGES_TO_READ]
        pages = []
        for row in ordered:
            print("   reading: " + short(row["url"], 70))
            page = fetch_page(row["url"])
            full = page is not None and len(page["text"]) > 200
            text = (page["text"] if full else row["title"] + " " + row["snippet"]).lower()
            matched = [f["label"] for f in idea["features"] if any(has_term(text, k) for k in f["keywords"])]
            commercial = is_commercial(text)
            raw_pct = 100.0 * len(matched) / max(1, len(idea["features"]))
            score = raw_pct * (1.0 if commercial else 0.5)
            pages.append({"url": row["url"], "title": row["title"], "full": full, "commercial": commercial, "matched": matched, "score": int(round(score))})
            time.sleep(0.3)
        pages.sort(key=lambda p: p["score"], reverse=True)
        overlap = pages[0]["score"] if pages else None
        heavy = len([p for p in pages if p["score"] >= HEAVY_PAGE_SCORE]) >= HEAVY_PAGE_COUNT or (overlap or 0) >= 40
        return {"idea": idea, "pages": pages, "overlap": overlap, "heavy": heavy, "queries": seen[:4]}

    def format_report(self, result):
        idea = result["idea"]
        lines = ["LIVE WEB CHECK: " + idea["name"], "  Searched: " + " | ".join(short(q, 40) for q in result["queries"])]
        pages = result["pages"]
        if not pages:
            lines.append("  No pages could be read, so the overlap is UNVERIFIED.")
            return "\n".join(lines)
        full = len([p for p in pages if p["full"]])
        lines.append("  Read " + str(len(pages)) + " pages (" + str(full) + " in full, " + str(len(pages) - full) + " from the search snippet only)")
        verdict = "OK" if result["overlap"] <= OVERLAP_LIMIT else "ABOVE THE LIMIT"
        if self.competition_ok:
            verdict = "competition is welcome"
        lines.append("  Market overlap: " + str(result["overlap"]) + "%   (limit " + str(OVERLAP_LIMIT) + "%)   " + verdict)
        lines.append("  Heavy competition: " + ("YES" if result["heavy"] else "no"))
        lines.append("  Closest pages:")
        for p in pages[:4]:
            kind = "product-like" if p["commercial"] else "informational"
            matched = ", ".join(p["matched"][:4]) if p["matched"] else "none"
            lines.append("   - " + str(p["score"]) + "%  " + kind + "  " + short(p["url"], 70))
            lines.append("       features found: " + short(matched, 80))
        return "\n".join(lines)

    def check_loop(self, idea):
        for round_number in range(MAX_ROUNDS):
            print("\n[Kerdos] Checking the live web for: " + short(idea["name"], 60))
            result = self.web_check(idea)
            report = self.format_report(result)
            print("\n" + report)
            if round_number == 0:
                print("\n" + METHOD_NOTE)
            self.reports.append(report)
            overlap = result["overlap"]
            if overlap is None:
                self.history.append({"role": "user", "content": "[Kerdos web check] The search returned nothing usable, so the overlap of '" + idea["name"] + "' is unverified. Say so honestly in one sentence."})
                self.stream_reply("Reply in one or two sentences. Do not ask a question.")
                return
            if self.competition_ok or overlap <= OVERLAP_LIMIT:
                self.finalize(result)
                return
            closest = "; ".join(p["url"] + " (" + str(p["score"]) + "%, features: " + ", ".join(p["matched"][:3]) + ")" for p in result["pages"][:3])
            if round_number == MAX_ROUNDS - 1:
                self.history.append({"role": "user", "content": "[Kerdos web check] Final result for '" + idea["name"] + "': measured market overlap " + str(overlap) + "% from live pages, above the " + str(OVERLAP_LIMIT) + "% limit. Closest: " + closest + ". Tell the user honestly in two or three sentences that it did not get under the limit and what you would try next. Do not ask more than one question."})
                self.stream_reply("Be honest. Use only the numbers given. Do not invent competitors.")
                return
            print("\n[Kerdos] Overlap is above " + str(OVERLAP_LIMIT) + "%. Asking the strategist for a narrower idea (round " + str(round_number + 2) + " of " + str(MAX_ROUNDS) + ").")
            self.history.append({"role": "user", "content": "[Kerdos web check] Live pages show '" + idea["name"] + "' has " + str(overlap) + "% market overlap, above the " + str(OVERLAP_LIMIT) + "% limit. Closest real pages: " + closest + ". Present ONE narrower, more specific idea that avoids what those pages already do: its name, a one-sentence pitch, the audience, the problem, and the method. Do not ask a question."})
            reply = self.stream_reply("Present one narrower concrete idea. Do not claim any overlap number. Do not ask a question.")
            if reply is None:
                return
            new_idea = self.extract_idea(reply)
            if not new_idea:
                print("[Kerdos] I could not read the narrowed idea. Type /check to try again.")
                return
            self.checked.add(new_idea["name"].lower())
            idea = new_idea

    def finalize(self, result):
        idea = result["idea"]
        overlap = result["overlap"]
        note = "competition is welcome for this user" if self.competition_ok else "within the " + str(OVERLAP_LIMIT) + "% limit"
        closest = "; ".join(p["url"] for p in result["pages"][:3]) or "none"
        self.history.append({"role": "user", "content": "[Kerdos web check] '" + idea["name"] + "' measured " + str(overlap) + "% market overlap from live pages (" + note + "). Heavy competition: " + ("yes" if result["heavy"] else "no") + ". Closest pages: " + closest + ". Present the final business model: the name, pitch, how it fits the user's job role, the genre, the problem, the measured overlap and how it was measured (a live DuckDuckGo search and reading real pages today, " + datetime.date.today().isoformat() + "), and the Kerdos tiers: a Yearly plan at $100/year and a Premium Lifetime plan at $300, saying what the customer gets in each. Use only the numbers and links given. End without asking a question."})
        self.stream_reply("Use only the numbers and links given. Never invent competitors or links.")

    def save(self):
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = "kerdos_live_interview_" + stamp + ".txt"
        lines = []
        for i, message in enumerate(self.history):
            if message["role"] == "system":
                continue
            if i == 1 and message["role"] == "user":
                continue
            label = "You" if message["role"] == "user" else "Strategist"
            lines.append(label + ": " + message["content"] + "\n")
        if self.reports:
            lines.append("WEB CHECK REPORTS\n")
            lines.extend(r + "\n" for r in self.reports)
            lines.append(METHOD_NOTE + "\n")
        with open(path, "w", encoding="utf-8") as handle:
            handle.write("\n".join(lines))
        print("Saved to " + os.path.abspath(path))


def read_line():
    try:
        return input("\nYou: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\nGoodbye.")
        return None


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print("=" * 64)
    print(" Kerdos Live Business Thinker (AI runs on this computer)")
    print(" Model: " + MODEL + "    Live web check: " + ("ON (" + SEARCH_PACKAGE + ")" if DDGS else "OFF"))
    print(" Type /help for commands")
    print("=" * 64)
    if DDGS is None:
        print("The search library is missing, so ideas cannot be checked against the web.")
        print("Install it with:  pip install ddgs      (or: pip install duckduckgo-search)")
        sys.exit(1)
    if not check_ollama():
        sys.exit(1)
    interview = KerdosInterview()
    interview.send(KICKOFF, count_turn=False)
    while True:
        text = read_line()
        if text is None:
            break
        if not text:
            continue
        command = text.lower()
        if command in ("/quit", "/exit", "quit", "exit"):
            print("Goodbye.")
            break
        if command == "/help":
            print(HELP_TEXT)
            continue
        if command == "/save":
            interview.save()
            continue
        if command == "/reset":
            interview.reset()
            print("\nStarting a fresh interview.")
            interview.send(KICKOFF, count_turn=False)
            continue
        if command == "/check":
            if interview.last_reply:
                interview.try_check(interview.last_reply, forced=True)
            continue
        interview.send(text)


if __name__ == "__main__":
    main()
