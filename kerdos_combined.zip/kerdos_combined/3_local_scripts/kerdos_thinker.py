#!/usr/bin/env python3
import datetime
import os
import sys

try:
    import ollama
except ImportError:
    print("The 'ollama' Python library is not installed.")
    print("Install it with:  pip install ollama")
    sys.exit(1)

MODEL = os.environ.get("KERDOS_MODEL", "llama3")
CONTEXT_SIZE = 8192
TEMPERATURE = 0.7
IDEAS_MIN_ANSWERS = 6

SYSTEM_PROMPT = """You are an advanced, independent AI Business Strategist. Your purpose is to collaborate with the user to discover a tailored business idea, target job role, and industry genre.
Core Rules:
- NO FIXED QUESTION TEMPLATES: You are strictly forbidden from using pre-scripted, quiz-like, or templated questions. Every question must be fully organic, custom-built in real-time, and adaptive based strictly on what information is logically missing.
- ONE QUESTION PER TURN: Keep the user experience conversational. Never ask multiple questions at once. Ask one tailored question, wait for the response, and adapt.
- ABSOLUTE SLANG & CONTEXT FLUENCY: You have native comprehension of modern internet culture and slang (e.g., 'doom scrolling', 'brain rot'). You must NEVER interpret slang as a literal product or business asset. If a user names a habit like 'doom scrolling,' your next question must dynamically address that behavioral ecosystem (e.g., attention algorithms, digital fatigue) as a source for discovery.
- IDEATION CONSTRAINTS: Unless the user explicitly selects 'Yes' to an early concept on the very first question, any final business idea you generate must be a completely novel synthesis with a maximum 10% market overlap against real-world companies. All finalized business models must structurally include Kerdos's tiered pricing framework: a $100/year subscription and a $300 premium lifetime access plan."""

KICKOFF = (
    "Begin the interview now. Greet me in one short sentence, then ask your first question: "
    "whether I want to enter a market that already has existing business competition. "
    "Ask only that one question."
)

HELP_TEXT = """Commands:
  /ideas   ask the strategist to present your business ideas now
  /save    save this conversation to a text file
  /reset   start a brand new interview
  /help    show this list
  /quit    leave (Ctrl+C also works)"""


def model_name(entry):
    try:
        return entry["model"]
    except Exception:
        pass
    try:
        return entry["name"]
    except Exception:
        return str(getattr(entry, "model", ""))


def check_ollama():
    try:
        response = ollama.list()
    except Exception as err:
        print("Could not reach Ollama on this computer.")
        print("Start the Ollama app (or run 'ollama serve' in another window) and try again.")
        print("Details: " + str(err))
        return False
    try:
        models = response["models"]
    except Exception:
        models = getattr(response, "models", [])
    names = [model_name(m) for m in models]
    if not any(n.startswith(MODEL) for n in names):
        print("The model '" + MODEL + "' is not downloaded yet.")
        print("Download it with:  ollama pull " + MODEL)
        return False
    return True


class KerdosInterview:
    def __init__(self):
        self.reset()

    def reset(self):
        self.history = [{"role": "system", "content": SYSTEM_PROMPT}]
        self.user_turns = 0
        self.correction = ""

    def build_reminder(self, force_ideas):
        lines = [
            "Reminder for this turn: follow every Core Rule in your instructions.",
            "Ask at most one question, with exactly one question mark. Never use a quiz-style or scripted question.",
            "Read slang by its behavioral meaning, never as a literal product or asset.",
            "Remember everything the user has told you in this conversation and build on it.",
        ]
        if force_ideas:
            lines += [
                "The user wants their ideas now. Present exactly three completely novel business ideas built from everything they told you.",
                "For each idea give: a made-up name, a one-sentence pitch, how it fits their job role, the industry genre, the real problem it solves, and an honest market overlap estimate.",
                "You cannot browse the web, so say clearly that the overlap figure is your own estimate. Do not fake a low number.",
                "Unless the user said Yes to entering a competitive market on the very first question, each idea must be narrow enough to honestly be 10 percent overlap or less.",
                "For each idea include the Kerdos tiers: a Yearly plan at $100/year and a Premium Lifetime plan at $300, and say what the customer gets in each.",
                "If you still lack their job role, genre, a real problem, weekly hours, or budget, say what is missing in one short sentence and ask one question instead.",
            ]
        elif self.user_turns < IDEAS_MIN_ANSWERS:
            lines.append("Do not suggest any business ideas yet. You have only had " + str(self.user_turns) + " answers. Keep learning about their job role or skills, the genre they want, real problems they have seen, a secondary interest, their weekly hours, and their budget.")
        else:
            lines.append("You may present three business ideas only if you already know the job role or skills, the genre, a real problem, a secondary interest, weekly hours, and budget. Otherwise keep asking exactly one question about what is missing.")
        if self.correction:
            lines.append(self.correction)
        return "\n".join(lines)

    def send(self, user_text, count_turn=True, force_ideas=False):
        self.history.append({"role": "user", "content": user_text})
        messages = self.history + [{"role": "system", "content": self.build_reminder(force_ideas)}]
        self.correction = ""
        parts = []
        print("\nStrategist: ", end="", flush=True)
        try:
            stream = ollama.chat(
                model=MODEL,
                messages=messages,
                stream=True,
                options={"num_ctx": CONTEXT_SIZE, "temperature": TEMPERATURE},
            )
            for chunk in stream:
                piece = chunk["message"]["content"]
                parts.append(piece)
                print(piece, end="", flush=True)
        except KeyboardInterrupt:
            self.history.pop()
            print("\n(Cancelled. Your last message was not kept. Type it again to retry.)")
            return
        except Exception as err:
            self.history.pop()
            print("\n\nSomething went wrong talking to Ollama: " + str(err))
            print("Check that the Ollama app is running, then type your message again.")
            return
        print()
        reply = "".join(parts).strip()
        self.history.append({"role": "assistant", "content": reply})
        if count_turn:
            self.user_turns += 1
        is_final = "$100" in reply or "$300" in reply
        if reply.count("?") > 1 and not is_final:
            self.correction = "Your previous reply asked more than one question. From now on ask exactly one question."

    def save(self):
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = "kerdos_interview_" + stamp + ".txt"
        lines = []
        for i, message in enumerate(self.history):
            if message["role"] == "system":
                continue
            if i == 1 and message["role"] == "user":
                continue
            label = "You" if message["role"] == "user" else "Strategist"
            lines.append(label + ": " + message["content"] + "\n")
        with open(path, "w", encoding="utf-8") as handle:
            handle.write("\n".join(lines))
        print("Saved to " + os.path.abspath(path))


def read_line():
    try:
        return input("\nYou: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\nGoodbye.")
        return None


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print("=" * 60)
    print(" Kerdos AI Business Thinker (runs fully on this computer)")
    print(" Model: " + MODEL + "    Type /help for commands")
    print("=" * 60)
    if not check_ollama():
        sys.exit(1)
    interview = KerdosInterview()
    interview.send(KICKOFF, count_turn=False)
    while True:
        text = read_line()
        if text is None:
            break
        if not text:
            continue
        command = text.lower()
        if command in ("/quit", "/exit", "quit", "exit"):
            print("Goodbye.")
            break
        if command == "/help":
            print(HELP_TEXT)
            continue
        if command == "/save":
            interview.save()
            continue
        if command == "/reset":
            interview.reset()
            print("\nStarting a fresh interview.")
            interview.send(KICKOFF, count_turn=False)
            continue
        if command == "/ideas":
            interview.send("Please present my business ideas now.", count_turn=False, force_ideas=True)
            continue
        interview.send(text)


if __name__ == "__main__":
    main()
