#!/usr/bin/env python3
import datetime
import json
import os
import re
import sys
import time

try:
    import ollama
except ImportError:
    print("The 'ollama' Python library is not installed.")
    print("Install it with:  pip install ollama ddgs")
    sys.exit(1)

DDGS = None
if os.environ.get("KERDOS_WEB", "1") != "0":
    try:
        from ddgs import DDGS
    except ImportError:
        try:
            from duckduckgo_search import DDGS
        except ImportError:
            DDGS = None
WEB_OK = DDGS is not None

MODEL = os.environ.get("KERDOS_MODEL", "llama3")
CONTEXT_SIZE = 8192
TEMPERATURE = 0.7
IDEAS_MIN_ANSWERS = 6
OVERLAP_LIMIT = 10
MAX_ROUNDS = 2
MAX_QUERIES = 4
RESULTS_PER_QUERY = 6
KEEP_RESULTS = 8
SEARCH_PAUSE = 1.0

SYSTEM_PROMPT = """You are an advanced, independent AI Business Strategist. Your purpose is to collaborate with the user to discover a tailored business idea, target job role, and industry genre.
Core Rules:
- NO FIXED QUESTION TEMPLATES: You are strictly forbidden from using pre-scripted, quiz-like, or templated questions. Every question must be fully organic, custom-built in real-time, and adaptive based strictly on what information is logically missing.
- ONE QUESTION PER TURN: Keep the user experience conversational. Never ask multiple questions at once. Ask one tailored question, wait for the response, and adapt.
- ABSOLUTE SLANG & CONTEXT FLUENCY: You have native comprehension of modern internet culture and slang (e.g., 'doom scrolling', 'brain rot'). You must NEVER interpret slang as a literal product or business asset. If a user names a habit like 'doom scrolling,' your next question must dynamically address that behavioral ecosystem (e.g., attention algorithms, digital fatigue) as a source for discovery.
- IDEATION CONSTRAINTS: Unless the user explicitly selects 'Yes' to an early concept on the very first question, any final business idea you generate must be a completely novel synthesis with a maximum 10% market overlap against real-world companies. All finalized business models must structurally include Kerdos's tiered pricing framework: a $100/year subscription and a $300 premium lifetime access plan."""

KICKOFF = (
    "Begin the interview now. Greet me in one short sentence, then ask your first question: "
    "whether I want to enter a market that already has existing business competition. "
    "Ask only that one question."
)

HELP_TEXT = """Commands:
  /ideas         search the web for competitors and present your business ideas
  /ideas force   do the same even if the interview is still short
  /save          save this conversation and the competitor evidence to a text file
  /reset         start a brand new interview
  /help          show this list
  /quit          leave (Ctrl+C also works)

To check ideas made on the Kerdos website, download kerdos_ideas.json there and run:
  python kerdos_thinker_web.py --check kerdos_ideas.json"""

STOP_WORDS = set(
    "the and for with that this from your you our their into over under using use based "
    "have has are was were will can not but all any more most some such than then them they "
    "what when where which who how why about after before also each other only own same "
    "very just like make made help helps new".split()
)

YES_WORDS = ("yes", "y", "yeah", "yep", "yup", "sure", "absolutely", "definitely")


def words(text):
    found = set()
    for word in re.findall(r"[a-zA-Z]{4,}", text.lower()):
        if word not in STOP_WORDS:
            found.add(word)
    return found


def match_score(idea_words, text):
    if not idea_words:
        return 0
    hits = len(idea_words & words(text))
    return int(round(100.0 * hits / len(idea_words)))


def short(value, size=90):
    text = str(value).replace("\n", " ").strip()
    return text if len(text) <= size else text[: size - 1] + "~"


def parse_json(text):
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end < start:
        return None
    try:
        return json.loads(text[start : end + 1])
    except ValueError:
        return None


def model_name(entry):
    try:
        return entry["model"]
    except Exception:
        pass
    try:
        return entry["name"]
    except Exception:
        return str(getattr(entry, "model", ""))


def check_ollama():
    try:
        response = ollama.list()
    except Exception as err:
        print("Could not reach Ollama on this computer.")
        print("Start the Ollama app (or run 'ollama serve' in another window) and try again.")
        print("Details: " + str(err))
        return False
    try:
        models = response["models"]
    except Exception:
        models = getattr(response, "models", [])
    names = [model_name(m) for m in models]
    if not any(n.startswith(MODEL) for n in names):
        print("The model '" + MODEL + "' is not downloaded yet.")
        print("Download it with:  ollama pull " + MODEL)
        return False
    return True


def web_search(query):
    try:
        with DDGS() as client:
            rows = client.text(query, max_results=RESULTS_PER_QUERY)
    except Exception as err:
        print("      (search failed: " + short(err, 70) + ")")
        return []
    results = []
    for row in rows or []:
        url = row.get("href") or row.get("url") or ""
        if url:
            results.append({"title": row.get("title", ""), "url": url, "snippet": row.get("body", "")})
    return results


def clean_idea(raw):
    def text(key):
        return str(raw.get(key, "")).strip()

    queries = raw.get("queries", [])
    if not isinstance(queries, list):
        queries = []
    return {
        "name": text("name"),
        "pitch": text("pitch"),
        "audience": text("audience"),
        "problem": text("problem"),
        "method": text("method"),
        "queries": [str(q).strip() for q in queries if str(q).strip()],
        "evidence": [],
        "overlap": None,
        "closest": [],
        "reasoning": "",
    }


class KerdosInterview:
    def __init__(self):
        self.reset()

    def reset(self):
        self.history = [{"role": "system", "content": SYSTEM_PROMPT}]
        self.user_turns = 0
        self.correction = ""
        self.competition_ok = False
        self.evidence_text = ""

    def options(self):
        return {"num_ctx": CONTEXT_SIZE, "temperature": TEMPERATURE}

    def build_reminder(self, ideas_mode):
        lines = [
            "Reminder for this turn: follow every Core Rule in your instructions.",
            "Ask at most one question, with exactly one question mark. Never use a quiz-style or scripted question.",
            "Read slang by its behavioral meaning, never as a literal product or asset.",
            "Remember everything the user has told you in this conversation and build on it.",
        ]
        if ideas_mode:
            lines += [
                "The user wants their ideas now, but web search is unavailable. Present exactly three completely novel business ideas built from everything they told you.",
                "For each idea give: a made-up name, a one-sentence pitch, how it fits their job role, the industry genre, the real problem it solves, and an overlap estimate.",
                "You cannot browse the web, so say clearly that the overlap figure is your own unverified estimate. Do not fake a low number.",
                "Each idea must include the Kerdos tiers: a Yearly plan at $100/year and a Premium Lifetime plan at $300, and say what the customer gets in each.",
            ]
        elif self.user_turns < IDEAS_MIN_ANSWERS:
            lines.append("Do not suggest any business ideas yet. You have only had " + str(self.user_turns) + " answers. Keep learning about their job role or skills, the genre they want, real problems they have seen, a secondary interest, their weekly hours, and their budget.")
        else:
            lines.append("Never present business ideas in normal conversation. If you already know their job role or skills, the genre, a real problem, a secondary interest, weekly hours, and budget, tell them in one short sentence to type /ideas, which runs a real web competition check. Otherwise ask exactly one question about what is missing.")
        if self.correction:
            lines.append(self.correction)
        return "\n".join(lines)

    def send(self, user_text, count_turn=True, ideas_mode=False):
        first_real_answer = count_turn and self.user_turns == 0
        self.history.append({"role": "user", "content": user_text})
        messages = self.history + [{"role": "system", "content": self.build_reminder(ideas_mode)}]
        self.correction = ""
        parts = []
        print("\nStrategist: ", end="", flush=True)
        try:
            stream = ollama.chat(model=MODEL, messages=messages, stream=True, options=self.options())
            for chunk in stream:
                piece = chunk["message"]["content"]
                parts.append(piece)
                print(piece, end="", flush=True)
        except KeyboardInterrupt:
            self.history.pop()
            print("\n(Cancelled. Your last message was not kept. Type it again to retry.)")
            return
        except Exception as err:
            self.history.pop()
            print("\n\nSomething went wrong talking to Ollama: " + str(err))
            print("Check that the Ollama app is running, then type your message again.")
            return
        print()
        reply = "".join(parts).strip()
        self.history.append({"role": "assistant", "content": reply})
        if first_real_answer:
            first_word = user_text.strip().lower().split(" ")[0].strip(".,!?")
            self.competition_ok = first_word in YES_WORDS
        if count_turn:
            self.user_turns += 1
        if self.user_turns == IDEAS_MIN_ANSWERS and count_turn:
            print("\n(You can type /ideas whenever you are ready for the web competition check.)")
        is_final = "$100" in reply or "$300" in reply
        if reply.count("?") > 1 and not is_final:
            self.correction = "Your previous reply asked more than one question. From now on ask exactly one question."

    def chat_json(self, messages):
        try:
            response = ollama.chat(model=MODEL, messages=messages, stream=False, format="json", options=self.options())
            return parse_json(response["message"]["content"])
        except KeyboardInterrupt:
            raise
        except Exception as err:
            print("   (the model call failed: " + short(err, 80) + ")")
            return None

    def draft_ideas(self):
        rule = "Unless the user said Yes to entering a competitive market on the very first question, each idea must be narrow enough that real companies cover at most 10 percent of it." if not self.competition_ok else "The user is happy to enter a market that already has competition."
        prompt = (
            "Using everything the user told you, write exactly THREE completely novel business ideas. " + rule + "\n"
            "Make each idea specific: a named audience, a concrete problem, and a concrete method. Interpret slang by meaning, never as a product.\n"
            "Return ONLY a JSON object shaped like: "
            '{"summary": "under 80 words covering job role or skills, genre, problems, secondary interest, weekly hours, budget, equipment limits", '
            '"ideas": [{"name": "invented name", "pitch": "one sentence", "audience": "who buys", "problem": "real problem", '
            '"method": "how it works in under 10 words", "queries": ["three different web search queries a person would use to find existing competitors", "", ""]}]}'
        )
        messages = self.history + [{"role": "system", "content": prompt}]
        for attempt in range(2):
            data = self.chat_json(messages)
            if data and isinstance(data.get("ideas"), list):
                ideas = [clean_idea(x) for x in data["ideas"] if isinstance(x, dict)]
                ideas = [x for x in ideas if x["name"]][:3]
                if ideas:
                    return str(data.get("summary", "")).strip(), ideas
        return None

    def gather(self, idea):
        key_words = words(idea["name"] + " " + idea["method"] + " " + idea["audience"] + " " + idea["problem"])
        queries = list(idea["queries"][:3])
        queries.append(short(idea["method"] + " for " + idea["audience"], 80))
        queries.append(short(idea["problem"] + " app OR service OR tool", 80))
        seen_queries = []
        for q in queries:
            if q and q not in seen_queries:
                seen_queries.append(q)
        seen_urls = {}
        for q in seen_queries[:MAX_QUERIES]:
            print("   searching: " + short(q, 70))
            for row in web_search(q):
                if row["url"] not in seen_urls:
                    row["match"] = match_score(key_words, row["title"] + " " + row["snippet"])
                    seen_urls[row["url"]] = row
            time.sleep(SEARCH_PAUSE)
        results = sorted(seen_urls.values(), key=lambda r: r["match"], reverse=True)[:KEEP_RESULTS]
        idea["evidence"] = results
        print("   found " + str(len(results)) + " pages")

    def evidence_block(self, ideas):
        parts = []
        for i, idea in enumerate(ideas, 1):
            parts.append("IDEA %d: %s | audience: %s | problem: %s | method: %s" % (i, idea["name"], idea["audience"], idea["problem"], idea["method"]))
            if not idea["evidence"]:
                parts.append("  (no web results were found for this idea)")
            for r in idea["evidence"]:
                parts.append("  - [keyword match %d%%] %s | %s | %s" % (r["match"], short(r["title"], 80), r["url"], short(r["snippet"], 160)))
        return "\n".join(parts)

    def assess(self, summary, ideas):
        limit_rule = "The user accepts competition, so no pivot is needed." if self.competition_ok else "The overlap limit is " + str(OVERLAP_LIMIT) + " percent. If an idea's overlap_percent is above " + str(OVERLAP_LIMIT) + ", fill in pivot with a narrower, more specific version of the idea (same fields as an idea, with three fresh search queries). Otherwise set pivot to null."
        prompt = (
            "You are judging how much each business idea overlaps with real companies. Use ONLY the web search evidence below. Do not invent competitors or URLs.\n"
            "User profile: " + summary + "\n\n" + self.evidence_block(ideas) + "\n\n"
            "For each idea, overlap_percent is your honest integer estimate of how much of the idea is already offered by real companies, judged from the evidence. Do not shade it down. If no results were found, set overlap_percent to -1.\n"
            + limit_rule + "\n"
            "Return ONLY a JSON object shaped like: "
            '{"assessments": [{"overlap_percent": 0, "closest": [{"name": "company or product", "url": "a URL copied from the evidence", "why": "short reason"}], '
            '"reasoning": "one sentence", "pivot": null}]} with one assessment per idea, in the same order.'
        )
        messages = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": prompt}]
        data = self.chat_json(messages)
        if not data or not isinstance(data.get("assessments"), list):
            return None
        return data["assessments"]

    def apply_assessments(self, ideas, assessments):
        pivoted = []
        for i, idea in enumerate(ideas):
            a = assessments[i] if i < len(assessments) and isinstance(assessments[i], dict) else {}
            try:
                idea["overlap"] = int(a.get("overlap_percent", -1))
            except (TypeError, ValueError):
                idea["overlap"] = -1
            urls = {r["url"] for r in idea["evidence"]}
            idea["closest"] = []
            for c in a.get("closest", []) if isinstance(a.get("closest"), list) else []:
                if isinstance(c, dict) and c.get("url") in urls:
                    idea["closest"].append({"name": str(c.get("name", "")), "url": c["url"], "why": str(c.get("why", ""))})
            idea["reasoning"] = str(a.get("reasoning", ""))
            pivot = a.get("pivot")
            if not self.competition_ok and idea["overlap"] > OVERLAP_LIMIT and isinstance(pivot, dict) and pivot.get("name"):
                pivoted.append((i, clean_idea(pivot)))
        return pivoted

    def evidence_report(self, ideas):
        lines = ["Competition evidence from the web search on " + datetime.date.today().isoformat() + ":"]
        for i, idea in enumerate(ideas, 1):
            if idea["overlap"] is None or idea["overlap"] < 0:
                overlap = "unverified (no usable results)"
            else:
                overlap = str(idea["overlap"]) + "% estimated overlap"
            lines.append("")
            lines.append("Idea " + str(i) + ": " + idea["name"] + "  [" + overlap + "]")
            if idea["closest"]:
                lines.append("  Closest real competitors:")
                for c in idea["closest"]:
                    lines.append("   - " + c["name"] + "  " + c["url"] + "  (" + short(c["why"], 80) + ")")
            lines.append("  Top pages found:")
            if not idea["evidence"]:
                lines.append("   - none")
            for r in idea["evidence"][:5]:
                lines.append("   - [" + str(r["match"]) + "% keyword match] " + short(r["title"], 60) + "  " + r["url"])
        lines.append("")
        lines.append("Search results show what exists on the open web. They are strong evidence, not proof. Niche or new products can be missing, so check the links yourself.")
        return "\n".join(lines)

    def present_ideas(self, force):
        if self.user_turns < IDEAS_MIN_ANSWERS and not force:
            print("\nYou have given " + str(self.user_turns) + " answers so far. Ideas work best after " + str(IDEAS_MIN_ANSWERS) + ".")
            print("Keep going, or type /ideas force to run the check now.")
            return
        if not WEB_OK:
            print("\nWeb search is not available, so I will use an offline estimate instead.")
            print("To enable it, run:  pip install ddgs   and start the script again.")
            self.send("Please present my business ideas now.", count_turn=False, ideas_mode=True)
            return
        try:
            self.run_web_check()
        except KeyboardInterrupt:
            print("\n(Cancelled.)")

    def run_web_check(self):
        print("\nStrategist: Let me draft candidate ideas from everything you told me.")
        drafted = self.draft_ideas()
        if not drafted:
            print("I could not draft ideas in a usable format. Try /ideas again, or answer a few more questions first.")
            return
        summary, ideas = drafted
        self.run_loop(summary, ideas)

    def run_loop(self, summary, ideas):
        todo = list(range(len(ideas)))
        for round_number in range(MAX_ROUNDS + 1):
            for i in todo:
                print("\nChecking the web for idea " + str(i + 1) + ": " + short(ideas[i]["name"], 60))
                self.gather(ideas[i])
            print("\nJudging overlap from the evidence")
            assessments = self.assess(summary, ideas)
            if assessments is None:
                print("The model could not judge the results. The raw evidence is shown below.")
                assessments = []
            pivoted = self.apply_assessments(ideas, assessments)
            if self.competition_ok or round_number == MAX_ROUNDS or not pivoted:
                break
            todo = []
            for index, new_idea in pivoted:
                print("Idea " + str(index + 1) + " overlapped too much (" + str(ideas[index]["overlap"]) + "%). Narrowing it to: " + short(new_idea["name"], 60))
                ideas[index] = new_idea
                todo.append(index)
        self.final_answer(summary, ideas)

    def final_answer(self, summary, ideas):
        data_lines = []
        for i, idea in enumerate(ideas, 1):
            if idea["overlap"] is None or idea["overlap"] < 0:
                overlap = "unverified, the web search returned nothing usable"
            else:
                overlap = str(idea["overlap"]) + " percent, estimated from web search results"
            closest = "; ".join(c["name"] + " (" + c["url"] + ")" for c in idea["closest"]) or "none identified"
            data_lines.append(
                "Idea %d: %s. Pitch: %s. Audience: %s. Problem: %s. Method: %s. Overlap: %s. Closest real competitors: %s. Reasoning: %s"
                % (i, idea["name"], idea["pitch"], idea["audience"], idea["problem"], idea["method"], overlap, closest, idea["reasoning"])
            )
        rule = "If an idea's overlap is above " + str(OVERLAP_LIMIT) + " percent, say honestly that it did not reach the limit." if not self.competition_ok else "The user accepts competition."
        prompt = (
            "Present these three verified business ideas to the user in a friendly, clear way. Use the overlap numbers and competitors exactly as given, and never add competitors or links that are not listed.\n"
            "User profile: " + summary + "\n" + "\n".join(data_lines) + "\n"
            "For each idea write: the name, the pitch, how it fits the user's job role, the genre, the problem it solves, the overlap result and what it was based on (a web search done on " + datetime.date.today().isoformat() + "), and the Kerdos tiers: a Yearly plan at $100/year and a Premium Lifetime plan at $300, saying what the customer gets in each. "
            + rule + " End with one short sentence offering to refine any idea. Do not ask more than one question."
        )
        messages = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": prompt}]
        parts = []
        print("\nStrategist: ", end="", flush=True)
        try:
            for chunk in ollama.chat(model=MODEL, messages=messages, stream=True, options=self.options()):
                piece = chunk["message"]["content"]
                parts.append(piece)
                print(piece, end="", flush=True)
        except Exception as err:
            print("\n(The model could not write the summary: " + short(err, 80) + ")")
        print()
        reply = "".join(parts).strip()
        report = self.evidence_report(ideas)
        print("\n" + report)
        self.evidence_text = report
        self.history.append({"role": "user", "content": "Please present my business ideas now."})
        self.history.append({"role": "assistant", "content": reply or "The ideas and evidence are listed above."})
        self.history.append({"role": "system", "content": "Verified competition data from a real web search, for follow-up questions:\n" + report})

    def save_report(self):
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = "kerdos_competition_report_" + stamp + ".txt"
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(self.evidence_text + "\n")
        print("Report saved to " + os.path.abspath(path))

    def save(self):
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = "kerdos_interview_" + stamp + ".txt"
        lines = []
        for i, message in enumerate(self.history):
            if message["role"] == "system":
                continue
            if i == 1 and message["role"] == "user":
                continue
            label = "You" if message["role"] == "user" else "Strategist"
            lines.append(label + ": " + message["content"] + "\n")
        if self.evidence_text:
            lines.append(self.evidence_text + "\n")
        with open(path, "w", encoding="utf-8") as handle:
            handle.write("\n".join(lines))
        print("Saved to " + os.path.abspath(path))


def load_ideas_file(path):
    with open(path, encoding="utf-8") as handle:
        data = json.load(handle)
    ideas = [clean_idea(x) for x in data.get("ideas", []) if isinstance(x, dict)]
    ideas = [x for x in ideas if x["name"]][:3]
    return str(data.get("summary", "")), str(data.get("gate", "no")).lower() == "yes", ideas


def check_mode(path):
    if not WEB_OK:
        print("Web search is not installed. Run:  pip install ddgs")
        return 1
    if not check_ollama():
        return 1
    try:
        summary, competition_ok, ideas = load_ideas_file(path)
    except (OSError, ValueError) as err:
        print("Could not read " + path + ": " + str(err))
        return 1
    if not ideas:
        print("No ideas were found in " + path)
        return 1
    interview = KerdosInterview()
    interview.competition_ok = competition_ok
    print("Checking " + str(len(ideas)) + " ideas from " + path + " against the real web.")
    try:
        interview.run_loop(summary, ideas)
    except KeyboardInterrupt:
        print("\n(Cancelled.)")
        return 1
    interview.save_report()
    return 0


def read_line():
    try:
        return input("\nYou: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\nGoodbye.")
        return None


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    if len(sys.argv) >= 3 and sys.argv[1] == "--check":
        sys.exit(check_mode(sys.argv[2]))
    print("=" * 62)
    print(" Kerdos AI Business Thinker (the AI runs on this computer)")
    print(" Model: " + MODEL + "    Web competition check: " + ("ON" if WEB_OK else "OFF"))
    print(" Type /help for commands")
    print("=" * 62)
    if not WEB_OK:
        print("Web search is off. To turn it on, run:  pip install ddgs")
    if not check_ollama():
        sys.exit(1)
    interview = KerdosInterview()
    interview.send(KICKOFF, count_turn=False)
    while True:
        text = read_line()
        if text is None:
            break
        if not text:
            continue
        command = text.lower()
        if command in ("/quit", "/exit", "quit", "exit"):
            print("Goodbye.")
            break
        if command == "/help":
            print(HELP_TEXT)
            continue
        if command == "/save":
            interview.save()
            continue
        if command == "/reset":
            interview.reset()
            print("\nStarting a fresh interview.")
            interview.send(KICKOFF, count_turn=False)
            continue
        if command in ("/ideas", "/ideas force"):
            interview.present_ideas(command == "/ideas force")
            continue
        interview.send(text)


if __name__ == "__main__":
    main()
