import envload  # noqa: F401  (loads a local .env file before anything reads settings)

import hashlib
import hmac
import html as htmllib
import json
import os
import re
import secrets
import threading
import time
import urllib.error
import urllib.request
import uuid
from collections import defaultdict, deque
from functools import wraps

from flask import Flask, Response, g, jsonify, request, send_from_directory, stream_with_context

import auth
import billing
import db
import engine
import intel
import tasks

DATA_DIR = os.environ.get("DATA_DIR", "data")
APPROVAL_WINDOW = int(os.environ.get("APPROVAL_WINDOW_SECONDS", "300"))
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "")
TRUST_PROXY = os.environ.get("TRUST_PROXY", "1") == "1"
RD_AUTORUN_MINUTES = int(os.environ.get("RD_AUTORUN_MINUTES", "360"))
NOTIFY_URL = os.environ.get("NOTIFY_WEBHOOK_URL", "")
RD_MIN_EVENTS = int(os.environ.get("RD_MIN_EVENTS", "10"))
FREE_RUNS = int(os.environ.get("FREE_IDEA_RUNS_PER_MONTH", "1"))
LIFETIME_RUNS = int(os.environ.get("LIFETIME_RUNS_PER_MONTH", "30"))
PAID_RUNS = int(os.environ.get("PAID_RUNS_PER_MONTH", "60"))
SPRINT_RUNS = int(os.environ.get("SPRINT_RUNS", "10"))
FOUNDING_LIMIT = int(os.environ.get("FOUNDING_LIMIT", "25"))
REFERRAL_CAP = int(os.environ.get("REFERRAL_CAP", "5"))
REFUND_DAYS = int(os.environ.get("REFUND_DAYS", "0"))
COST_PER_CALL = float(os.environ.get("COST_PER_CALL_USD", "0.01"))
DAILY_CALL_ALERT = int(os.environ.get("DAILY_CALL_ALERT", "500"))
FRONTEND_URL = os.environ.get("FRONTEND_URL", "").rstrip("/")
TEST_CHECKOUT = os.environ.get("ALLOW_TEST_CHECKOUT", "0") == "1"
ALLOWED_ORIGINS = [o.strip().rstrip("/") for o in os.environ.get("ALLOWED_ORIGINS", "").split(",") if o.strip()]
LIMITS = {
    "interview": (int(os.environ.get("INTERVIEW_PER_MINUTE", "40")), 60),
    "ideas": (int(os.environ.get("IDEAS_PER_HOUR", "10")), 3600),
    "recheck": (int(os.environ.get("RECHECK_PER_HOUR", "20")), 3600),
    "tool": (int(os.environ.get("TOOL_PER_HOUR", "60")), 3600),
    "event": (120, 60),
    "billing": (20, 600),
    "auth_ip": (8, 600),
    "auth_verify": (20, 600),
}
CLIENT_EVENTS = ("page_open", "gate_chosen", "step_leave", "dropdown_used", "recheck_clicked", "pivot_adopted", "search_link_clicked", "tier_clicked", "checkout_card_error", "checkout_success", "client_error", "home_cta", "tab_viewed", "login_opened", "login_success", "share_clicked", "watch_clicked", "invite_clicked")
TIER_NAMES = {"monthly": "Monthly Pass", "annual": "Annual Strategy Accelerator", "lifetime": "Lifetime Founder Access", "sprint": "Launch Sprint"}
PRICES = {"monthly": 10, "annual": 100, "lifetime": 300, "sprint": 39}

os.makedirs(DATA_DIR, exist_ok=True)
db.init()
app = Flask(__name__, static_folder="static", static_url_path="")
app.config["MAX_CONTENT_LENGTH"] = 200000
llm = engine.LLM()
lock = threading.Lock()
hits = defaultdict(deque)
EVENTS_FILE = os.path.join(DATA_DIR, "events.jsonl")
STAGING_FILE = os.path.join(DATA_DIR, "staging.json")
LIVE_FILE = os.path.join(DATA_DIR, "live.json")


@app.after_request
def add_cors(response):
    origin = request.headers.get("Origin", "")
    if origin and not request.path.startswith("/api/admin") and not request.path.startswith("/api/stripe"):
        if "*" in ALLOWED_ORIGINS:
            response.headers["Access-Control-Allow-Origin"] = "*"
        elif origin.rstrip("/") in ALLOWED_ORIGINS:
            response.headers["Access-Control-Allow-Origin"] = origin
            response.headers["Vary"] = "Origin"
        if "Access-Control-Allow-Origin" in response.headers:
            response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
            response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
            response.headers["Access-Control-Max-Age"] = "600"
    return response


def read_json(path, default):
    try:
        with open(path, encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return default


def write_json(path, data):
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2)


def log_event(kind, **fields):
    record = {"t": kind, "ts": int(time.time())}
    record.update(fields)
    with lock:
        with open(EVENTS_FILE, "a", encoding="utf-8") as handle:
            handle.write(json.dumps(record) + "\n")


def read_events():
    events = []
    try:
        with open(EVENTS_FILE, encoding="utf-8") as handle:
            for line in handle:
                try:
                    events.append(json.loads(line))
                except ValueError:
                    continue
    except OSError:
        pass
    return events


def client_ip():
    if TRUST_PROXY:
        forwarded = request.headers.get("X-Forwarded-For", "")
        if forwarded:
            return forwarded.split(",")[0].strip()
    return request.remote_addr or "unknown"


def bearer():
    header = request.headers.get("Authorization", "")
    return header[7:].strip() if header.startswith("Bearer ") else ""


def current_user():
    if not hasattr(g, "user_checked"):
        token = bearer()
        g.user = auth.user_from_token(token) if token else None
        g.user_checked = True
    return g.user


def is_admin_user(user):
    return user is not None and auth.is_super_admin(user["email"])


def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if current_user() is None:
            return jsonify({"error": "Please log in to continue.", "login": True}), 401
        return view(*args, **kwargs)
    return wrapper


def limited(bucket, user=None):
    if is_admin_user(user):
        return False
    limit, window = LIMITS[bucket]
    if limit <= 0:
        return False
    key = bucket + ":" + client_ip() + (":" + str(user["id"]) if user else "")
    now = time.time()
    with lock:
        queue = hits[key]
        while queue and now - queue[0] > window:
            queue.popleft()
        if len(queue) >= limit:
            return True
        queue.append(now)
    return False


def too_many():
    return jsonify({"error": "You are going very fast. Please wait a little and try again."}), 429


def sse(generator):
    def run():
        try:
            for event in generator:
                yield "data: " + json.dumps(event) + "\n\n"
        except engine.LLMError as err:
            app.logger.error("LLM error: %s", err)
            log_event("llm_error")
            yield "data: " + json.dumps({"t": "error", "v": "The AI service had a hiccup. Please try again in a moment."}) + "\n\n"
        except Exception as err:
            app.logger.exception("stream failed: %s", err)
            log_event("server_error")
            yield "data: " + json.dumps({"t": "error", "v": "Something went wrong on our side. Please try again."}) + "\n\n"
        yield "data: " + json.dumps({"t": "done"}) + "\n\n"

    return Response(stream_with_context(run()), mimetype="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


def body_json():
    return request.get_json(silent=True) or {}


def clean_gate(value):
    return "Yes" if value == "Yes" else "No"


def sid_of(body):
    sid = str(body.get("sid", ""))[:40]
    return sid if re.fullmatch(r"[A-Za-z0-9_-]{6,40}", sid) else "anon"


def run_cap(user):
    if is_admin_user(user) or not auth.entitled(user):
        return None
    return {"lifetime": LIFETIME_RUNS, "sprint": SPRINT_RUNS}.get(user["plan"], PAID_RUNS)


def founding_left():
    return max(0, FOUNDING_LIMIT - db.count_lifetime())


def user_view(user):
    admin = is_admin_user(user)
    entitled = auth.entitled(user)
    used = db.count_results_since(user["id"], int(time.time()) - 30 * 86400)
    cap = run_cap(user)
    return {
        "email": user["email"], "plan": "super_admin" if admin else user["plan"], "plan_status": "lifetime" if admin else user["plan_status"],
        "is_admin": admin, "paid": entitled, "unlimited": admin, "free_runs_left": None if entitled else max(0, FREE_RUNS - used) + user["bonus_runs"],
        "runs_used": used, "run_cap": cap, "runs_left": None if cap is None else max(0, cap - used), "bonus_runs": user["bonus_runs"],
        "sprint_expires": user["plan_expires"] if user["plan"] == "sprint" else None, "ref_code": db.ensure_ref_code(user),
    }


@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.route("/admin")
def admin_page():
    return send_from_directory(app.static_folder, "admin.html")


@app.route("/healthz")
def healthz():
    return jsonify({"ok": True})


@app.route("/api/config")
def config():
    return jsonify({"stripe": billing.configured(), "test_checkout": TEST_CHECKOUT, "free_runs": FREE_RUNS})


@app.route("/api/auth/request", methods=["POST"])
def auth_request():
    email = auth.normalize(body_json().get("email"))
    if not email:
        return jsonify({"error": "Enter a valid email address."}), 400
    if limited("auth_ip"):
        return too_many()
    with lock:
        key = "auth_email:" + email
        queue = hits[key]
        now = time.time()
        while queue and now - queue[0] > 3600:
            queue.popleft()
        if len(queue) >= 5:
            return jsonify({"error": "That is a lot of codes for one address. Please wait an hour or use the latest code."}), 429
        queue.append(now)
    try:
        sent = auth.request_code(email)
    except Exception as err:
        app.logger.error("mail failed: %s", err)
        sent = False
    if not sent:
        return jsonify({"error": "We could not send the login code right now. Please try again later."}), 503
    return jsonify({"ok": True})


def apply_ref(user, ref):
    if not re.fullmatch(r"[a-z0-9_-]{3,24}", ref or ""):
        return
    partner = db.query("SELECT code FROM partners WHERE code = ?", (ref,), one=True)
    if partner:
        db.execute("UPDATE users SET partner = ? WHERE id = ?", (partner["code"], user["id"]))
        return
    referrer = db.user_by_ref(ref)
    if referrer and referrer["id"] != user["id"] and db.referral_count(referrer["id"]) < REFERRAL_CAP:
        db.execute("UPDATE users SET referred_by = ? WHERE id = ?", (referrer["id"], user["id"]))
        db.add_bonus(referrer["id"], 1)
        db.add_bonus(user["id"], 1)


@app.route("/api/auth/verify", methods=["POST"])
def auth_verify():
    body = body_json()
    email = auth.normalize(body.get("email"))
    code = str(body.get("code", "")).strip()
    if not email or not re.fullmatch(r"\d{6}", code):
        return jsonify({"error": "That code is not right or has expired."}), 400
    if limited("auth_verify"):
        return too_many()
    if not auth.verify_code(email, code):
        return jsonify({"error": "That code is not right or has expired."}), 400
    existing = db.user_by_email(email)
    user = db.get_or_create_user(email)
    if existing is None:
        apply_ref(user, str(body.get("ref", "")).strip().lower())
        user = db.get_user(user["id"])
    token = auth.create_session(user["id"])
    log_event("login_success", sid=sid_of(body))
    return jsonify({"token": token, "user": user_view(user)})


@app.route("/api/auth/logout", methods=["POST"])
@login_required
def auth_logout():
    auth.end_session(bearer())
    return jsonify({"ok": True})


@app.route("/api/me")
@login_required
def me():
    user = current_user()
    saved = db.load_interview(user["id"])
    return jsonify({"user": user_view(user), "progress": {"active": bool(saved and saved["hist"]), "answered": len(saved["hist"]) if saved else 0}, "history_count": len(db.list_results(user["id"], 50))})


@app.route("/api/progress")
@login_required
def progress():
    saved = db.load_interview(current_user()["id"])
    if not saved or not saved["hist"]:
        return jsonify({"active": False})
    saved["active"] = True
    saved["ready"] = saved["question"] == ""
    return jsonify(saved)


@app.route("/api/history")
@login_required
def history():
    return jsonify({"items": db.list_results(current_user()["id"])})


@app.route("/api/history/<int:result_id>")
@login_required
def history_item(result_id):
    result = db.get_result(current_user()["id"], result_id)
    if not result:
        return jsonify({"error": "not found"}), 404
    return jsonify(result)


@app.route("/api/interview", methods=["POST"])
@login_required
def interview():
    user = current_user()
    body = body_json()
    hist = tasks.clean_hist(body.get("hist", []))
    if hist is None:
        return jsonify({"error": "bad request"}), 400
    if limited("interview", user):
        return too_many()
    gate = clean_gate(body.get("gate"))
    started = time.time()
    try:
        result = tasks.interview_turn(llm, gate, hist, user["memory"])
    except engine.LLMError as err:
        app.logger.error("LLM error: %s", err)
        log_event("llm_error")
        return jsonify({"error": "The AI service had a hiccup. Please try again."}), 502
    if result is None:
        log_event("interview_unreadable")
        return jsonify({"error": "The AI answered in a way I could not read. Please try again."}), 502
    db.save_interview(user["id"], gate, hist, result["question"], result["intro"], result["learned"])
    log_event("interview_turn", sid=sid_of(body), n=len(hist), ms=int((time.time() - started) * 1000), ready=result["ready"])
    return jsonify(result)


@app.route("/api/ideas", methods=["POST"])
@login_required
def ideas():
    user = current_user()
    body = body_json()
    hist = tasks.clean_hist(body.get("hist", []))
    if hist is None or not hist:
        return jsonify({"error": "bad request"}), 400
    if limited("ideas", user):
        return too_many()
    use_bonus = False
    if not is_admin_user(user):
        used = db.count_results_since(user["id"], int(time.time()) - 30 * 86400)
        cap = run_cap(user)
        if cap is not None and used >= cap:
            return jsonify({"error": "You have used all " + str(cap) + " idea runs included in your plan this month. Your runs reset on a rolling 30-day basis.", "cap": True}), 402
        if not auth.entitled(user) and used >= FREE_RUNS:
            if user["bonus_runs"] > 0:
                use_bonus = True
            else:
                return jsonify({"error": "You have used your " + str(FREE_RUNS) + " free idea run this month. Invite a friend for a bonus run, or choose a plan.", "upgrade": True}), 402
    sid = sid_of(body)
    gate = clean_gate(body.get("gate"))
    saved = db.load_interview(user["id"])
    learned = saved["learned"] if saved else []
    memory = user["memory"]

    def generate():
        started = time.time()
        for event in tasks.ideas_pipeline(llm, gate, hist, intel.record, memory):
            if event["t"] == "result":
                cards = event["v"]["ideas"]
                log_event("ideas_run", sid=sid, seconds=int(time.time() - started), overlaps=[c["overlap"] for c in cards if c["overlap"] is not None],
                          uncovered=[x for c in cards for x in c["gaps"]][:12], hosts=[p["url"].split("/")[2] for c in cards for p in c["pages"][:2] if p["url"].count("/") >= 2][:8])
                for c in cards:
                    c.pop("gaps", None)
                result_id = db.save_result(user["id"], gate, event["v"]["profile"], cards)
                db.set_memory(user["id"], tasks.merge_memory(memory, tasks.memory_line(event["v"]["profile"], cards, learned)))
                db.clear_interview(user["id"])
                if use_bonus:
                    db.add_bonus(user["id"], -1)
                event["v"]["result_id"] = result_id
            yield event

    return sse(generate())


@app.route("/api/recheck", methods=["POST"])
@login_required
def recheck():
    user = current_user()
    body = body_json()
    idea = body.get("idea")
    evidence = str(body.get("evidence", ""))[:3000]
    if not isinstance(idea, dict) or len(json.dumps(idea)) > 8000:
        return jsonify({"error": "bad request"}), 400
    if limited("recheck", user):
        return too_many()
    try:
        result = tasks.recheck(llm, clean_gate(body.get("gate")), idea, evidence, intel.record)
    except engine.LLMError as err:
        app.logger.error("LLM error: %s", err)
        return jsonify({"error": "The AI service had a hiccup. Please try again."}), 502
    for card in [result["idea"], result["pivot"]]:
        if card:
            card.pop("gaps", None)
    return jsonify(result)


@app.route("/api/tool", methods=["POST"])
@login_required
def tool():
    user = current_user()
    body = body_json()
    key = body.get("tool")
    idea = body.get("idea")
    profile = body.get("profile") if isinstance(body.get("profile"), dict) else {}
    if key not in tasks.TOOL_BRIEFS or not isinstance(idea, dict) or len(json.dumps(idea)) > 12000:
        return jsonify({"error": "bad request"}), 400
    if key in tasks.PREMIUM_TOOLS and not auth.entitled(user):
        return jsonify({"error": "This tool is part of Kerdos Professional. Choose a plan to unlock it.", "upgrade": True}), 402
    if limited("tool", user):
        return too_many()
    try:
        result = tasks.tool(llm, key, idea, profile, clean_gate(body.get("gate")))
    except engine.LLMError as err:
        app.logger.error("LLM error: %s", err)
        return jsonify({"error": "The AI service had a hiccup. Please try again."}), 502
    if result is None:
        return jsonify({"error": "The AI answered in a way I could not read. Please try again."}), 502
    log_event("tool_used", key=key)
    return jsonify(result)


@app.route("/api/billing/checkout", methods=["POST"])
@login_required
def billing_checkout():
    user = current_user()
    tier = body_json().get("tier")
    if tier not in TIER_NAMES:
        return jsonify({"error": "bad request"}), 400
    if limited("billing", user):
        return too_many()
    if tier == "lifetime" and founding_left() <= 0:
        return jsonify({"error": "All founding-member spots are taken."}), 409
    if not billing.configured():
        return jsonify({"error": "Payments are not set up yet."}), 503
    base = os.environ.get("FRONTEND_URL") or request.host_url
    try:
        url = billing.create_checkout(user, tier, base)
    except ValueError as err:
        return jsonify({"error": str(err)}), 503
    except (urllib.error.URLError, KeyError) as err:
        app.logger.error("stripe checkout failed: %s", err)
        return jsonify({"error": "The payment service had a hiccup. Please try again."}), 502
    return jsonify({"url": url})


@app.route("/api/billing/test", methods=["POST"])
@login_required
def billing_test():
    user = current_user()
    if not TEST_CHECKOUT:
        return jsonify({"error": "Test checkout is turned off."}), 403
    body = body_json()
    tier = body.get("tier")
    digits = re.sub(r"\D", "", str(body.get("card", "")))
    if tier not in TIER_NAMES:
        return jsonify({"error": "bad request"}), 400
    if digits not in ("4242", "4242424242424242"):
        return jsonify({"error": "Test mode accepts only the test card. Type 4242 to continue."}), 400
    if tier == "lifetime" and founding_left() <= 0:
        return jsonify({"error": "All founding-member spots are taken."}), 409
    billing.set_plan(user["id"], tier, "lifetime" if tier == "lifetime" else "active", expires=billing.sprint_expiry() if tier == "sprint" else None)
    log_event("checkout_test", tier=tier)
    return jsonify({"user": user_view(db.get_user(user["id"])), "tier": TIER_NAMES[tier]})


@app.route("/api/stripe/webhook", methods=["POST"])
def stripe_webhook():
    payload = request.get_data()
    if not billing.verify_signature(payload, request.headers.get("Stripe-Signature", ""), os.environ.get("STRIPE_WEBHOOK_SECRET", "")):
        return jsonify({"error": "bad signature"}), 400
    try:
        event = json.loads(payload.decode())
    except ValueError:
        return jsonify({"error": "bad payload"}), 400
    result = billing.apply_event(event)
    log_event("stripe_event", event_type=str(event.get("type", ""))[:40], result=result)
    return jsonify({"received": True})


@app.route("/api/event", methods=["POST"])
def event():
    body = body_json()
    if body.get("type") in CLIENT_EVENTS and not limited("event"):
        detail = body.get("d") if isinstance(body.get("d"), dict) else {}
        small = {k: (v if isinstance(v, (int, float)) else str(v)[:40]) for k, v in list(detail.items())[:4]}
        log_event(body["type"], sid=sid_of(body), **small)
    return ("", 204)


@app.route("/api/live")
def live():
    items = read_json(LIVE_FILE, [])
    return jsonify([{"title": i["title"], "summary": i["summary"], "approved": i["approved"]} for i in items[-20:]])


def summarize_events(events):
    def of(kind):
        return [e for e in events if e["t"] == kind]

    def count(kind):
        return len(of(kind))

    def tally(items, key):
        out = {}
        for e in items:
            k = str(e.get(key, "unknown"))
            out[k] = out.get(k, 0) + 1
        return out

    turns = of("interview_turn")
    reach = defaultdict(set)
    for e in turns:
        reach[e.get("n", 0)].add(e.get("sid"))
    funnel = {"turn_" + str(k): len(reach[k]) for k in sorted(reach)[:20]}
    ms = sorted(e.get("ms", 0) for e in turns)
    runs = of("ideas_run")
    overlaps = sorted(o for e in runs for o in e.get("overlaps", []))
    gaps = tally([{"g": x} for e in runs for x in e.get("uncovered", [])], "g")
    top_gaps = dict(sorted(gaps.items(), key=lambda kv: kv[1], reverse=True)[:10])
    return {
        "events": len(events), "page_open": count("page_open"), "home_cta_clicks": count("home_cta"), "tabs_viewed": tally(of("tab_viewed"), "tab"),
        "login_opened": count("login_opened"), "login_success": count("login_success"), "gate_chosen": tally(of("gate_chosen"), "gate"),
        "interview_funnel": funnel, "interview_turn_median_ms": ms[len(ms) // 2] if ms else None, "interview_turn_p90_ms": ms[min(len(ms) - 1, int(len(ms) * 0.9))] if ms else None,
        "sessions_reaching_ideas": len({e.get("sid") for e in runs}), "ideas_runs": len(runs),
        "median_ideas_seconds": sorted(e.get("seconds", 0) for e in runs)[len(runs) // 2] if runs else None,
        "median_overlap_percent": overlaps[len(overlaps) // 2] if overlaps else None,
        "share_overlap_above_10_percent": round(100 * len([o for o in overlaps if o > 10]) / len(overlaps)) if overlaps else None,
        "uncovered_feature_counts_across_ideas": top_gaps,
        "errors": {"llm_error": count("llm_error"), "server_error": count("server_error"), "interview_unreadable": count("interview_unreadable"), "client_error": count("client_error")},
        "tool_use": tally(of("tool_used"), "key"), "dropdown_clicks": tally(of("dropdown_used"), "key"),
        "recheck_clicks": count("recheck_clicked"), "pivots_adopted": count("pivot_adopted"), "search_links_clicked": count("search_link_clicked"),
        "tier_clicks": tally(of("tier_clicked"), "tier"), "checkout_card_errors": count("checkout_card_error"), "checkout_success": count("checkout_test"),
        "where_people_leave": tally(of("step_leave"), "step"),
    }


def require_admin():
    token = bearer()
    if ADMIN_TOKEN and token and hmac.compare_digest(token.encode(), ADMIN_TOKEN.encode()):
        return None
    if is_admin_user(current_user()):
        return None
    if not ADMIN_TOKEN and current_user() is None:
        return jsonify({"error": "admin disabled: log in as an admin or set ADMIN_TOKEN"}), 401
    return jsonify({"error": "unauthorized"}), 401


def refresh_expired(items):
    now = time.time()
    for item in items:
        if item["status"] == "pending" and now > item["expires"]:
            item["status"] = "expired"


def notify(titles):
    if titles:
        send_webhook("Kerdos R&D staged " + str(len(titles)) + " item(s) for approval. You have " + str(APPROVAL_WINDOW // 60) + " minutes: " + "; ".join(titles[:5]))


def send_webhook(text):
    if not NOTIFY_URL:
        return
    try:
        request_obj = urllib.request.Request(NOTIFY_URL, data=json.dumps({"text": text, "content": text}).encode(), headers={"Content-Type": "application/json"}, method="POST")
        urllib.request.urlopen(request_obj, timeout=8).close()
    except Exception as err:
        app.logger.warning("notify failed: %s", err)


def rd_generate():
    usage = summarize_events(read_events())
    if usage["events"] < RD_MIN_EVENTS:
        return {"status": "insufficient_input", "detail": "Only " + str(usage["events"]) + " events recorded. At least " + str(RD_MIN_EVENTS) + " are needed.", "staged": []}
    prompt = tasks.RD_SYS + "\n\nTASK:rd\nINPUT DATA (JSON):\n" + json.dumps({"usage": usage, "competitors": intel.summary()}) + "\n\nReturn only the JSON object."
    data = engine.parse_json(llm.complete([{"role": "user", "content": prompt}], as_json=True, max_tokens=engine.MAX_TOKENS * 2))
    if not data:
        return {"status": "error", "detail": "The agent reply was not valid JSON.", "staged": []}
    now = time.time()
    staged = []
    titles = []
    with lock:
        items = read_json(STAGING_FILE, [])
        refresh_expired(items)
        recent = {i["title"].lower() for i in items if i["status"] in ("pending", "approved") and now - i["created"] < 7 * 86400}

        def add(kind, entry, evidence, summary):
            title = str(entry.get("title", "")).strip()
            if not title or title.lower() in recent:
                return
            recent.add(title.lower())
            items.append({"id": uuid.uuid4().hex[:8], "kind": kind, "title": title, "summary": summary[:400], "evidence": evidence, "payload": entry, "created": now, "expires": now + APPROVAL_WINDOW, "status": "pending"})
            staged.append(items[-1]["id"])
            titles.append(title)

        for m in data.get("feature_ideas", []) if isinstance(data.get("feature_ideas"), list) else []:
            if isinstance(m, dict) and str(m.get("evidence", "")).strip():
                add("feature_idea", m, str(m["evidence"]), str(m.get("description", "")))
        for m in data.get("visual_micro_tweaks", []) if isinstance(data.get("visual_micro_tweaks"), list) else []:
            if isinstance(m, dict) and str(m.get("evidence", "")).strip():
                add("visual_tweak", m, str(m["evidence"]), str(m.get("change", "")))
        for m in data.get("macro_feature_bundles", []) if isinstance(data.get("macro_feature_bundles"), list) else []:
            if isinstance(m, dict) and isinstance(m.get("evidence"), list) and m["evidence"]:
                add("macro_bundle", m, "; ".join(str(e) for e in m["evidence"][:3]), "; ".join(str(c) for c in m.get("components", [])[:4]))
        for m in (data.get("content_pages", []) if isinstance(data.get("content_pages"), list) else [])[:2]:
            slug = re.sub(r"[^a-z0-9-]+", "-", str(m.get("slug", "")).lower()).strip("-")[:60] if isinstance(m, dict) else ""
            if isinstance(m, dict) and len(slug) >= 3 and str(m.get("evidence", "")).strip() and len(str(m.get("body", ""))) >= 200:
                m["slug"] = slug
                add("content_page", m, str(m["evidence"]), str(m["body"])[:200])
        write_json(STAGING_FILE, items)
    notify(titles)
    return {"status": "ok", "staged": staged, "window_seconds": APPROVAL_WINDOW, "limits": data.get("limits", [])}


def autonomous_loop():
    while True:
        time.sleep(RD_AUTORUN_MINUTES * 60)
        try:
            changed = intel.watch()
            log_event("competitor_watch", changed=len(changed))
            weekly_digests()
            rd_generate()
        except Exception as err:
            app.logger.exception("autonomous run failed: %s", err)


if RD_AUTORUN_MINUTES > 0 and os.environ.get("RD_DISABLE_THREAD", "0") != "1":
    threading.Thread(target=autonomous_loop, daemon=True).start()


@app.route("/api/admin/generate", methods=["POST"])
def admin_generate():
    denied = require_admin()
    return denied or jsonify(rd_generate())


@app.route("/api/admin/watch", methods=["POST"])
def admin_watch():
    denied = require_admin()
    return denied or jsonify({"changed": intel.watch()})


@app.route("/api/admin/competitors")
def admin_competitors():
    denied = require_admin()
    return denied or jsonify(intel.summary())


@app.route("/api/admin/users")
def admin_users():
    denied = require_admin()
    if denied:
        return denied
    rows = db.query("SELECT id, email, created, last_login, plan, plan_status FROM users ORDER BY id DESC LIMIT 200")
    for r in rows:
        r["super_admin"] = auth.is_super_admin(r["email"])
    return jsonify({"users": rows})


@app.route("/api/admin/users/plan", methods=["POST"])
def admin_user_plan():
    denied = require_admin()
    if denied:
        return denied
    body = body_json()
    email = auth.normalize(body.get("email"))
    plan = body.get("plan")
    user = db.user_by_email(email) if email else None
    if not user or plan not in ("free", "monthly", "annual", "lifetime"):
        return jsonify({"error": "bad request"}), 400
    billing.set_plan(user["id"], plan, "none" if plan == "free" else ("lifetime" if plan == "lifetime" else "active"))
    return jsonify({"ok": True})


@app.route("/api/admin/queue")
def admin_queue():
    denied = require_admin()
    if denied:
        return denied
    with lock:
        items = read_json(STAGING_FILE, [])
        refresh_expired(items)
        write_json(STAGING_FILE, items)
    return jsonify({"now": time.time(), "items": items[-60:], "live": read_json(LIVE_FILE, [])[-20:]})


def decide(item_id, decision):
    denied = require_admin()
    if denied:
        return denied
    with lock:
        items = read_json(STAGING_FILE, [])
        refresh_expired(items)
        item = next((i for i in items if i["id"] == item_id), None)
        if item is None:
            return jsonify({"error": "not found"}), 404
        if item["status"] == "expired":
            write_json(STAGING_FILE, items)
            return jsonify({"error": "The approval window has closed. Generate fresh ideas."}), 410
        if item["status"] != "pending":
            return jsonify({"error": "already " + item["status"]}), 409
        item["status"] = decision
        if decision == "approved":
            live_items = read_json(LIVE_FILE, [])
            live_items.append({"id": item["id"], "kind": item["kind"], "title": item["title"], "summary": item["summary"], "payload": item["payload"], "approved": int(time.time())})
            write_json(LIVE_FILE, live_items)
        write_json(STAGING_FILE, items)
    return jsonify({"ok": True, "status": decision})


@app.route("/api/admin/approve/<item_id>", methods=["POST"])
def approve(item_id):
    return decide(item_id, "approved")


@app.route("/api/admin/reject/<item_id>", methods=["POST"])
def reject(item_id):
    return decide(item_id, "rejected")


call_counts = defaultdict(int)
alerted_days = set()


def on_llm_call(path):
    day = time.strftime("%Y-%m-%d", time.gmtime())
    with lock:
        call_counts[day] += 1
        today = call_counts[day]
    log_event("llm_call")
    if DAILY_CALL_ALERT > 0 and today > DAILY_CALL_ALERT and day not in alerted_days:
        alerted_days.add(day)
        send_webhook("Kerdos AI calls today passed " + str(DAILY_CALL_ALERT) + ". Check the cost panel on the admin page.")


llm.hook = on_llm_call


def page_shell(title, inner, description=""):
    e = htmllib.escape
    return ('<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
            '<title>' + e(title) + ' | Kerdos Business</title><meta name="description" content="' + e(description[:160]) + '">'
            '<meta property="og:title" content="' + e(title) + '"><meta property="og:description" content="' + e(description[:160]) + '">'
            '<style>body{margin:0;background:#04060a;color:#e8f4f8;font-family:system-ui,sans-serif;line-height:1.6}main{max-width:720px;margin:0 auto;padding:36px 20px}'
            'a{color:#00f0ff}.card{background:#0b1016;border:1px solid #1a2a36;border-radius:6px;padding:20px;margin:16px 0}.big{font-size:40px;font-weight:800;color:#00f0ff}'
            '.btn{display:inline-block;background:#00f0ff;color:#001418;border-radius:4px;padding:12px 20px;font-weight:700;text-decoration:none}.fine{color:#86a0ad;font-size:14px}</style></head>'
            '<body><main>' + inner + '</main></body></html>')


def front_link(path="/", ref=""):
    base = FRONTEND_URL or ""
    return base + path + (("?ref=" + ref) if ref else "")


@app.route("/api/pricing")
def pricing():
    return jsonify({"free_runs": FREE_RUNS, "paid_runs": PAID_RUNS, "lifetime_runs": LIFETIME_RUNS, "sprint_runs": SPRINT_RUNS, "sprint_days": billing.SPRINT_DAYS,
                    "founding_limit": FOUNDING_LIMIT, "founding_left": founding_left(), "referral_cap": REFERRAL_CAP, "refund_days": REFUND_DAYS})


@app.route("/api/share", methods=["POST"])
@login_required
def share_create():
    user = current_user()
    body = body_json()
    try:
        result_id = int(body.get("result_id"))
        index = int(body.get("index"))
    except (TypeError, ValueError):
        return jsonify({"error": "bad request"}), 400
    result = db.get_result(user["id"], result_id)
    if not result or index < 0 or index >= len(result["ideas"]):
        return jsonify({"error": "not found"}), 404
    idea = result["ideas"][index]
    data = {k: idea.get(k) for k in ("name", "pitch", "audience", "genre", "overlap")}
    data["date"] = time.strftime("%Y-%m-%d", time.gmtime(result["created"]))
    token = secrets.token_urlsafe(9)
    db.execute("INSERT INTO shares (token, user_id, idea, created) VALUES (?, ?, ?, ?)", (token, user["id"], json.dumps(data), int(time.time())))
    log_event("share_created")
    return jsonify({"url": request.host_url.rstrip("/") + "/s/" + token})


@app.route("/s/<token>")
def share_page(token):
    row = db.query("SELECT * FROM shares WHERE token = ?", (token,), one=True)
    if not row:
        return Response(page_shell("Not found", "<h1>This link is not valid.</h1>"), status=404, mimetype="text/html")
    idea = json.loads(row["idea"])
    owner = db.get_user(row["user_id"])
    ref = (owner or {}).get("ref_code") or ""
    e = htmllib.escape
    overlap = "Could not be verified" if idea.get("overlap") is None else str(idea["overlap"]) + "% measured overlap"
    inner = ('<p class="fine">A business idea checked with Kerdos Business</p><h1>' + e(str(idea.get("name", ""))) + '</h1><p>' + e(str(idea.get("pitch", ""))) + '</p>'
             '<div class="card"><div class="big">' + e(overlap) + '</div><p class="fine">Measured on ' + e(str(idea.get("date", ""))) + ' by reading real web pages for matching keywords. '
             'This is evidence, not proof or a guarantee, and it does not predict earnings.</p></div>'
             '<p>Built for: ' + e(str(idea.get("audience", ""))) + '</p>'
             '<p><a class="btn" href="' + e(front_link("/", ref)) + '">Get your own ideas, checked the same way</a></p>'
             '<p class="fine">New members who join from this link get a bonus idea run.</p>')
    return Response(page_shell(str(idea.get("name", "Idea")), inner, str(idea.get("pitch", ""))), mimetype="text/html")


@app.route("/api/watch", methods=["POST"])
@login_required
def watch_create():
    user = current_user()
    if not auth.entitled(user):
        return jsonify({"error": "Weekly competitor alerts are part of a paid plan.", "upgrade": True}), 402
    body = body_json()
    try:
        result = db.get_result(user["id"], int(body.get("result_id")))
        idea = result["ideas"][int(body.get("index"))]
    except (TypeError, ValueError, KeyError, IndexError):
        return jsonify({"error": "not found"}), 404
    urls = [p["url"] for p in idea.get("pages", [])[:5] if p.get("url")]
    if not urls:
        return jsonify({"error": "No competitor pages were found for this idea, so there is nothing to watch."}), 400
    if len(db.query("SELECT id FROM watches WHERE user_id = ?", (user["id"],))) >= 10:
        return jsonify({"error": "You are already watching 10 ideas. Stop one first."}), 409
    intel.ensure(urls)
    now = int(time.time())
    db.execute("INSERT INTO watches (user_id, name, urls, created, last_digest) VALUES (?, ?, ?, ?, ?)", (user["id"], str(idea.get("name", ""))[:80], json.dumps(urls), now, now))
    return jsonify({"ok": True, "pages": len(urls)})


@app.route("/api/watches")
@login_required
def watch_list():
    rows = db.query("SELECT id, name, created FROM watches WHERE user_id = ? ORDER BY id DESC", (current_user()["id"],))
    return jsonify({"items": rows})


@app.route("/api/watch/delete", methods=["POST"])
@login_required
def watch_delete():
    db.execute("DELETE FROM watches WHERE id = ? AND user_id = ?", (int(body_json().get("id", 0) or 0), current_user()["id"]))
    return jsonify({"ok": True})


def weekly_digests():
    now = int(time.time())
    store = intel.load()
    sent = 0
    for w in db.query("SELECT * FROM watches"):
        if now - w["last_digest"] < 7 * 86400:
            continue
        db.execute("UPDATE watches SET last_digest = ? WHERE id = ?", (now, w["id"]))
        user = db.get_user(w["user_id"])
        changed = [(u, store[u]) for u in json.loads(w["urls"]) if u in store and store[u].get("changed_at", 0) > w["last_digest"]]
        if not user or not auth.entitled(user) or not changed:
            continue
        lines = ["These pages we found for your idea \"" + w["name"] + "\" changed this week:", ""]
        for url, item in changed:
            terms = ", ".join(item.get("last_added_terms", [])[:6])
            lines.append("- " + url + (" (new terms: " + terms + ")" if terms else ""))
        lines += ["", "Open Kerdos Business and re-check the idea to see how the overlap changed."]
        try:
            auth.send_mail(user["email"], "Competitor changes for " + w["name"], "\n".join(lines))
            sent += 1
        except Exception as err:
            app.logger.warning("digest mail failed: %s", err)
    return sent


@app.route("/api/admin/partners", methods=["GET", "POST"])
def admin_partners():
    denied = require_admin()
    if denied:
        return denied
    if request.method == "POST":
        body = body_json()
        code = re.sub(r"[^a-z0-9_-]", "", str(body.get("code", "")).lower())
        name = str(body.get("name", "")).strip()[:80]
        if len(code) < 3 or not name:
            return jsonify({"error": "Give a code of at least 3 letters or numbers and a name."}), 400
        db.execute("INSERT OR IGNORE INTO partners (code, name, created) VALUES (?, ?, ?)", (code, name, int(time.time())))
    rows = db.query("SELECT p.code, p.name, (SELECT COUNT(*) FROM users u WHERE u.partner = p.code) AS signups, (SELECT COUNT(*) FROM users u WHERE u.partner = p.code AND u.plan != 'free') AS paying FROM partners p ORDER BY p.created DESC")
    return jsonify({"partners": rows})


@app.route("/api/admin/costs")
def admin_costs():
    denied = require_admin()
    if denied:
        return denied
    now = time.time()
    today = time.strftime("%Y-%m-%d", time.gmtime(now))
    month = time.strftime("%Y-%m", time.gmtime(now))
    calls = [time.strftime("%Y-%m-%d", time.gmtime(e["ts"])) for e in read_events() if e["t"] == "llm_call"]
    today_n = len([d for d in calls if d == today])
    month_n = len([d for d in calls if d.startswith(month)])
    def n(sql):
        return db.query(sql, (int(now),), one=True)["n"]
    monthly = n("SELECT COUNT(*) AS n FROM users WHERE plan = 'monthly' AND plan_status IN ('active', 'trialing') AND ? > 0")
    annual = n("SELECT COUNT(*) AS n FROM users WHERE plan = 'annual' AND plan_status IN ('active', 'trialing') AND ? > 0")
    lifetime = n("SELECT COUNT(*) AS n FROM users WHERE plan = 'lifetime' AND ? > 0")
    sprint = n("SELECT COUNT(*) AS n FROM users WHERE plan = 'sprint' AND plan_expires > ?")
    mrr = monthly * PRICES["monthly"] + annual * PRICES["annual"] / 12.0
    cost = month_n * COST_PER_CALL
    payers = monthly + annual + lifetime + sprint
    return jsonify({
        "ai_calls_today": today_n, "ai_calls_this_month": month_n, "assumed_cost_per_call_usd": COST_PER_CALL, "estimated_ai_cost_this_month_usd": round(cost, 2),
        "daily_call_alert": DAILY_CALL_ALERT, "paying_users": {"monthly": monthly, "annual": annual, "lifetime": lifetime, "sprint_active": sprint},
        "estimated_recurring_revenue_per_month_usd": round(mrr, 2), "cost_per_paying_user_usd": round(cost / payers, 2) if payers else None,
        "estimated_margin_percent": round(100 * (mrr - cost) / mrr) if mrr > 0 else None,
        "note": "Costs are calls times COST_PER_CALL_USD, which you should set to your real average. Recurring revenue counts monthly and annual plans only.",
    })


def live_pages():
    return [i for i in read_json(LIVE_FILE, []) if i.get("kind") == "content_page" and isinstance(i.get("payload"), dict)]


@app.route("/api/reports")
def reports_api():
    return jsonify([{"title": i["title"], "slug": i["payload"].get("slug"), "approved": i["approved"]} for i in live_pages()])


@app.route("/reports")
def reports_index():
    e = htmllib.escape
    items = "".join('<div class="card"><h2><a href="/reports/' + e(str(i["payload"].get("slug", ""))) + '">' + e(i["title"]) + '</a></h2><p class="fine">' + e(i["summary"][:160]) + '</p></div>' for i in live_pages())
    return Response(page_shell("Research", "<h1>Research</h1>" + (items or "<p>Nothing published yet.</p>")), mimetype="text/html")


@app.route("/reports/<slug>")
def report_page(slug):
    e = htmllib.escape
    for item in live_pages():
        if item["payload"].get("slug") == slug:
            paragraphs = "".join("<p>" + e(p.strip()) + "</p>" for p in str(item["payload"].get("body", "")).split("\n") if p.strip())
            inner = "<h1>" + e(item["title"]) + "</h1>" + paragraphs + '<div class="card"><p>Want ideas checked this way for your own skills?</p><a class="btn" href="' + e(front_link("/")) + '">Start the interview</a></div><p class="fine">Figures come from aggregated Kerdos data and are not a guarantee of results.</p>'
            return Response(page_shell(item["title"], inner, str(item["payload"].get("body", ""))[:160]), mimetype="text/html")
    return Response(page_shell("Not found", "<h1>Not found</h1>"), status=404, mimetype="text/html")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8000")), threaded=True)
