import datetime
import hashlib
import ipaddress
import json
import os
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
from html.parser import HTMLParser

try:
    from ddgs import DDGS
except ImportError:
    try:
        from duckduckgo_search import DDGS
    except ImportError:
        DDGS = None

OVERLAP_LIMIT = 10
MAX_ROUNDS = int(os.environ.get("MAX_ROUNDS", "2"))
MAX_TOKENS = int(os.environ.get("LLM_MAX_TOKENS", "2048"))
RESULTS_PER_QUERY = 5
PAGES_TO_READ = int(os.environ.get("PAGES_TO_READ", "5"))
FETCH_TIMEOUT = int(os.environ.get("FETCH_TIMEOUT", "6"))
MAX_BYTES = 400000
MAX_TEXT = 12000
SEARCH_PAUSE = float(os.environ.get("SEARCH_PAUSE", "0.6"))
HEAVY_PAGE_SCORE = 30
HEAVY_PAGE_COUNT = 3
IDEAS_MIN_ANSWERS = 6
ALLOW_PRIVATE_FETCH = os.environ.get("ALLOW_PRIVATE_FETCH", "0") == "1"

SYSTEM_PROMPT = """You are an advanced, independent AI Business Strategist. Your purpose is to collaborate with the user to discover a tailored business idea, target job role, and industry genre.
Core Rules:
- NO FIXED QUESTION TEMPLATES: You are strictly forbidden from using pre-scripted, quiz-like, or templated questions. Every question must be fully organic, custom-built in real-time, and adaptive based strictly on what information is logically missing.
- ONE QUESTION PER TURN: Keep the user experience conversational. Never ask multiple questions at once. Ask one tailored question, wait for the response, and adapt.
- ABSOLUTE SLANG & CONTEXT FLUENCY: You have native comprehension of modern internet culture and slang (e.g., 'doom scrolling', 'brain rot'). You must NEVER interpret slang as a literal product or business asset. If a user names a habit like 'doom scrolling,' your next question must dynamically address that behavioral ecosystem (e.g., attention algorithms, digital fatigue) as a source for discovery.
- IDEATION CONSTRAINTS: Unless the user explicitly selects 'Yes' to an early concept on the very first question, any final business idea you generate must be a completely novel synthesis with a maximum 10% market overlap against real-world companies. All finalized business models must structurally include Kerdos's tiered pricing framework: a $100/year subscription and a $300 premium lifetime access plan."""

KICKOFF = (
    "Begin the interview now. Greet me warmly in one short sentence, in your own words. "
    "Then ask one natural question, in your own words, about whether I would be comfortable entering a market that already has competition. "
    "Ask only that one question."
)

TONE = (
    "Tone: you are a real-world strategic collaborator talking to a peer. Warm, intuitive, short active sentences. "
    "React to what they just said before your one question. No corporate AI fluff, no bullet lists, and never say 'As an AI' or 'I would be happy to assist'."
)

PRODUCT_CUES = (
    "pricing", "sign up", "signup", "subscribe", "free trial", "get started", "plans", "buy now",
    "download", "log in", "login", "per month", "/month", "add to cart", "book a demo", "join now",
)

PROVIDERS = {
    "gemini": ("https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.0-flash"),
    "openai": ("https://api.openai.com/v1", "gpt-4o-mini"),
    "compatible": ("http://localhost:1234/v1", ""),
    "ollama": ("http://localhost:11434", "llama3"),
}


class LLMError(Exception):
    pass


class LLM:
    def __init__(self):
        self.provider = os.environ.get("LLM_PROVIDER", "gemini").strip().lower()
        base, model = PROVIDERS.get(self.provider, PROVIDERS["compatible"])
        self.base = os.environ.get("LLM_BASE_URL", base).rstrip("/")
        self.model = os.environ.get("LLM_MODEL", model)
        fallback_name = "GEMINI_API_KEY" if self.provider == "gemini" else "OPENAI_API_KEY"
        self.key = os.environ.get("LLM_API_KEY") or os.environ.get(fallback_name, "")
        self.native = self.provider == "ollama"

    def headers(self):
        headers = {"Content-Type": "application/json"}
        if self.key:
            headers["Authorization"] = "Bearer " + self.key
        return headers

    hook = None

    def post(self, path, body):
        if self.hook:
            self.hook(path)
        request = urllib.request.Request(self.base + path, data=json.dumps(body).encode("utf-8"), headers=self.headers(), method="POST")
        try:
            return urllib.request.urlopen(request, timeout=120)
        except urllib.error.HTTPError as err:
            raise LLMError("HTTP " + str(err.code) + ": " + err.read().decode("utf-8", errors="replace")[:200])
        except urllib.error.URLError as err:
            raise LLMError("cannot reach the AI service (" + str(err.reason) + ")")

    def stream(self, messages, max_tokens=700):
        if self.native:
            body = {"model": self.model, "messages": messages, "stream": True, "options": {"num_ctx": 8192, "temperature": 0.7}}
            with self.post("/api/chat", body) as response:
                for raw in response:
                    line = raw.decode("utf-8").strip()
                    if not line:
                        continue
                    data = json.loads(line)
                    piece = data.get("message", {}).get("content", "")
                    if piece:
                        yield piece
                    if data.get("done"):
                        break
            return
        body = {"model": self.model, "messages": messages, "stream": True, "temperature": 0.7, "max_tokens": max_tokens}
        with self.post("/chat/completions", body) as response:
            for raw in response:
                line = raw.decode("utf-8").strip()
                if not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if payload == "[DONE]":
                    break
                choices = json.loads(payload).get("choices") or []
                if choices:
                    piece = (choices[0].get("delta") or {}).get("content") or ""
                    if piece:
                        yield piece

    def complete(self, messages, as_json=False, max_tokens=1500):
        if self.native:
            body = {"model": self.model, "messages": messages, "stream": False, "options": {"num_ctx": 8192, "temperature": 0.4}}
            if as_json:
                body["format"] = "json"
            with self.post("/api/chat", body) as response:
                return json.loads(response.read().decode("utf-8"))["message"]["content"]
        body = {"model": self.model, "messages": messages, "stream": False, "temperature": 0.4, "max_tokens": max_tokens}
        if as_json:
            body["response_format"] = {"type": "json_object"}
        try:
            with self.post("/chat/completions", body) as response:
                data = json.loads(response.read().decode("utf-8"))
        except LLMError as err:
            if as_json and "HTTP 400" in str(err):
                body.pop("response_format")
                with self.post("/chat/completions", body) as response:
                    data = json.loads(response.read().decode("utf-8"))
            else:
                raise
        return data["choices"][0]["message"]["content"]

    def json(self, prompt, max_tokens=1500):
        messages = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": prompt}]
        return parse_json(self.complete(messages, as_json=True, max_tokens=max_tokens))


def parse_json(text):
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end < start:
        return None
    try:
        return json.loads(text[start : end + 1])
    except ValueError:
        return None


def clip(value, size=90):
    text = str(value).replace("\n", " ").strip()
    return text if len(text) <= size else text[: size - 1] + "~"


def validate_history(history, require_last_user=True):
    if not isinstance(history, list) or len(history) > 40:
        return None
    clean = []
    for item in history:
        if not isinstance(item, dict) or item.get("role") not in ("user", "assistant"):
            return None
        content = item.get("content")
        if not isinstance(content, str) or not content.strip() or len(content) > 4000:
            return None
        clean.append({"role": item["role"], "content": content.strip()})
    if require_last_user and clean and clean[-1]["role"] != "user":
        return None
    return clean


def reminder(user_turns, last_assistant):
    lines = [
        "Hidden note for you, never mention it. Follow every Core Rule in your instructions.",
        "Ask at most one question, with exactly one question mark. Never use a scripted or quiz-style question.",
        "Read slang by its behavioral meaning, never as a literal product or asset.",
        "Remember everything the user has told you and build on it.",
        TONE,
    ]
    if user_turns < IDEAS_MIN_ANSWERS:
        lines.append("Do not suggest any business ideas yet. You have had " + str(user_turns) + " answers. Keep learning about their job role or skills, the genre they want, real problems they have seen, a secondary interest, their weekly hours, and their budget.")
    else:
        lines.append("If you know enough, tell the user in one short sentence that they can press the Present my ideas button, which runs a live web competition check. Otherwise ask exactly one question about what is missing.")
    if last_assistant and last_assistant.count("?") > 1:
        lines.append("Your previous reply asked more than one question. From now on ask exactly one question.")
    return "\n".join(lines)


def chat_messages(history):
    user_turns = len([m for m in history if m["role"] == "user"])
    last_assistant = ""
    for m in reversed(history):
        if m["role"] == "assistant":
            last_assistant = m["content"]
            break
    messages = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": KICKOFF}] + [dict(m) for m in history]
    messages[-1]["content"] += "\n\n[" + reminder(user_turns, last_assistant) + "]"
    return messages


def transcript(history):
    return "\n".join(("User: " if m["role"] == "user" else "Strategist: ") + m["content"] for m in history)[-6000:]


class TextExtractor(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.skip = 0
        self.parts = []
        self.title = ""
        self.meta = ""
        self.in_title = False

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style", "noscript", "svg"):
            self.skip += 1
        elif tag == "title":
            self.in_title = True
        elif tag == "meta":
            info = dict(attrs)
            if (info.get("name") or info.get("property") or "").lower() in ("description", "og:description"):
                self.meta += " " + (info.get("content") or "")

    def handle_endtag(self, tag):
        if tag in ("script", "style", "noscript", "svg") and self.skip > 0:
            self.skip -= 1
        elif tag == "title":
            self.in_title = False

    def handle_data(self, data):
        if self.skip:
            return
        if self.in_title:
            self.title += data
        else:
            self.parts.append(data)


def url_ok(url):
    try:
        parsed = urllib.parse.urlparse(url)
    except ValueError:
        return False
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        return False
    if ALLOW_PRIVATE_FETCH:
        return True
    if parsed.port not in (None, 80, 443):
        return False
    try:
        infos = socket.getaddrinfo(parsed.hostname, None)
    except OSError:
        return False
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast or ip.is_unspecified:
            return False
    return True


class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not url_ok(newurl):
            raise urllib.error.URLError("blocked redirect")
        return urllib.request.HTTPRedirectHandler.redirect_request(self, req, fp, code, msg, headers, newurl)


def fetch_page(url):
    if not url_ok(url):
        return None
    opener = urllib.request.build_opener(SafeRedirect)
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (compatible; KerdosResearch/1.0)", "Accept": "text/html"})
    try:
        with opener.open(request, timeout=FETCH_TIMEOUT) as response:
            if "html" not in response.headers.get("Content-Type", "").lower():
                return None
            raw = response.read(MAX_BYTES)
            charset = response.headers.get_content_charset() or "utf-8"
    except Exception:
        return None
    parser = TextExtractor()
    try:
        parser.feed(raw.decode(charset, errors="replace"))
    except Exception:
        pass
    body = " ".join(" ".join(parser.parts).split())
    return {"title": " ".join(parser.title.split()), "text": (parser.title + " " + parser.meta + " " + body)[:MAX_TEXT]}


def web_search(query):
    if DDGS is None:
        return []
    try:
        with DDGS() as client:
            rows = client.text(query, max_results=RESULTS_PER_QUERY)
    except Exception:
        return []
    results = []
    for row in rows or []:
        url = row.get("href") or row.get("url") or ""
        if url.startswith("http"):
            results.append({"title": row.get("title", ""), "url": url, "snippet": row.get("body", "")})
    return results


def top_terms(text, limit=200):
    counts = {}
    for word in re.findall(r"[a-z]{5,}", text.lower()):
        counts[word] = counts.get(word, 0) + 1
    ranked = sorted(counts.items(), key=lambda kv: kv[1], reverse=True)[:limit]
    return sorted(w for w, _ in ranked)


def has_term(text, term):
    term = term.strip().lower()
    return len(term) >= 3 and re.search(r"\b" + re.escape(term) + r"\b", text) is not None


def is_commercial(text):
    return len([c for c in PRODUCT_CUES if c in text]) >= 2


def clean_idea(raw):
    def text(key):
        return str(raw.get(key, "")).strip()

    queries = raw.get("queries", []) if isinstance(raw.get("queries"), list) else []
    features = []
    for item in raw.get("features", []) if isinstance(raw.get("features"), list) else []:
        if isinstance(item, dict) and isinstance(item.get("keywords"), list):
            words = [str(w).strip().lower() for w in item["keywords"] if len(str(w).strip()) >= 3]
            if words:
                features.append({"label": str(item.get("label", words[0])).strip(), "keywords": words[:3]})
    if len(features) < 5:
        for word in sorted(set(re.findall(r"[a-zA-Z]{6,}", (text("method") + " " + text("problem") + " " + text("audience")).lower()))):
            features.append({"label": word, "keywords": [word]})
    return {
        "name": text("name"), "pitch": text("pitch"), "audience": text("audience"), "problem": text("problem"), "method": text("method"),
        "queries": [str(q).strip() for q in queries if str(q).strip()][:3], "features": features[:12],
        "jobRole": text("jobRole"), "genre": text("genre"), "whyFit": text("whyFit"), "yearlyOffer": text("yearlyOffer"),
        "lifetimeOffer": text("lifetimeOffer"), "differentiator": text("differentiator"), "sig": text("sig"), "out": text("out"), "format": text("format"),
    }


def idea_schema():
    return (
        '{"name": "invented name", "pitch": "one sentence", "audience": "who buys", "problem": "real problem", "method": "how it works in under 10 words", '
        '"jobRole": "how it fits their job role", "genre": "short industry label", "whyFit": "one sentence on why it suits this person", '
        '"sig": "raw material the user already has, 2 to 4 words", "out": "what the product outputs, 2 to 4 words", "format": "one word like Studio or Toolkit", '
        '"yearlyOffer": "what the $100 per year plan includes", "lifetimeOffer": "what the $300 lifetime plan includes", "differentiator": "why nobody does exactly this", '
        '"queries": ["three different web search queries a person would use to find existing competitors", "", ""], '
        '"features": [{"label": "short feature name", "keywords": ["a specific word or short phrase a competitor page would use", ""]}]}'
    )


def detect_competition(llm, history):
    prompt = (
        "Read the conversation below. Did the user clearly say they are happy to enter a market that already has competition?\n"
        'Return ONLY JSON: {"competition_ok": true}. Answer true only for an explicit yes. If it is unclear or was never discussed, answer false.\n\n' + transcript(history)
    )
    data = llm.json(prompt, max_tokens=60)
    return bool(data and data.get("competition_ok") is True)


def draft_ideas(llm, history, competition_ok):
    rule = "The user is happy to enter a market that already has competition." if competition_ok else "Each idea must be narrow enough that real companies cover at most 10 percent of it."
    prompt = (
        "Using the conversation below, write exactly THREE completely novel business ideas. " + rule + "\n"
        "Make each idea specific: a named audience, a concrete problem, and a concrete method. Interpret slang by meaning, never as a product.\n"
        'Return ONLY JSON: {"summary": "under 80 words: job role or skills, genre, problems, interests, weekly hours, budget", "ideas": [' + idea_schema() + "]}\n"
        "Give each idea exactly 10 distinctive features. Do not use generic words like app, platform, subscription, or service as keywords.\n\n" + transcript(history)
    )
    for _ in range(2):
        data = llm.json(prompt, max_tokens=2500)
        if data and isinstance(data.get("ideas"), list):
            ideas = [clean_idea(x) for x in data["ideas"] if isinstance(x, dict)]
            ideas = [x for x in ideas if x["name"]][:3]
            if ideas:
                return str(data.get("summary", "")), ideas
    return None


def narrow_idea(llm, idea, summary, pages):
    closest = "; ".join(p["url"] + " (features found: " + ", ".join(p["matched"][:3]) + ")" for p in pages[:3])
    prompt = (
        "This business idea overlaps too much with real pages found on the web. Write ONE narrower, more specific idea that avoids what those pages already do.\n"
        "User profile: " + summary + "\nCurrent idea: " + json.dumps({k: idea[k] for k in ("name", "pitch", "audience", "problem", "method")}) + "\nClosest pages: " + closest + "\n"
        'Return ONLY JSON: {"idea": ' + idea_schema() + "} with exactly 10 distinctive features."
    )
    data = llm.json(prompt, max_tokens=1500)
    if data and isinstance(data.get("idea"), dict):
        new = clean_idea(data["idea"])
        if new["name"]:
            return new
    return None


def web_check(idea):
    queries = list(idea["queries"])
    queries.append(clip(idea["method"] + " " + idea["audience"], 80))
    seen = []
    for q in queries:
        if q and q not in seen:
            seen.append(q)
    per_query = []
    for q in seen[:4]:
        yield {"t": "status", "v": "Searching: " + clip(q, 60)}
        per_query.append(web_search(q))
        time.sleep(SEARCH_PAUSE)
    ordered = []
    hosts = set()
    for rank in range(max([len(r) for r in per_query] + [0])):
        for results in per_query:
            if rank < len(results):
                row = results[rank]
                host = urllib.parse.urlparse(row["url"]).netloc.lower().replace("www.", "")
                if host and host not in hosts:
                    hosts.add(host)
                    ordered.append(row)
    pages = []
    for row in ordered[:PAGES_TO_READ]:
        yield {"t": "status", "v": "Reading: " + clip(row["url"], 60)}
        page = fetch_page(row["url"])
        full = page is not None and len(page["text"]) > 200
        text = (page["text"] if full else row["title"] + " " + row["snippet"]).lower()
        matched = [f["label"] for f in idea["features"] if any(has_term(text, k) for k in f["keywords"])]
        commercial = is_commercial(text)
        raw_pct = 100.0 * len(matched) / max(1, len(idea["features"]))
        pages.append({
            "url": row["url"], "full": full, "commercial": commercial, "matched": matched, "score": int(round(raw_pct * (1.0 if commercial else 0.5))),
            "title": (page["title"] if full else row["title"])[:120], "hash": hashlib.sha1(text.encode("utf-8", errors="ignore")).hexdigest()[:12],
            "excerpt": (page["text"] if full else row["snippet"])[:240], "terms": top_terms(text) if full else [],
        })
    pages.sort(key=lambda p: p["score"], reverse=True)
    overlap = pages[0]["score"] if pages else None
    heavy = len([p for p in pages if p["score"] >= HEAVY_PAGE_SCORE]) >= HEAVY_PAGE_COUNT or (overlap or 0) >= 40
    return {"pages": pages, "overlap": overlap, "heavy": heavy}


def run_ideas(llm, history):
    if len([m for m in history if m["role"] == "user"]) < IDEAS_MIN_ANSWERS:
        yield {"t": "error", "v": "Chat a little longer first. Ideas work best after " + str(IDEAS_MIN_ANSWERS) + " answers."}
        return
    yield {"t": "status", "v": "Thinking through everything you told me"}
    competition_ok = detect_competition(llm, history)
    drafted = draft_ideas(llm, history, competition_ok)
    if not drafted:
        yield {"t": "error", "v": "I could not draft ideas just now. Please try again."}
        return
    summary, ideas = drafted
    finished = []
    for number, idea in enumerate(ideas, 1):
        for round_number in range(MAX_ROUNDS):
            yield {"t": "status", "v": "Idea " + str(number) + ": checking the live web for " + clip(idea["name"], 40)}
            check = yield from web_check(idea)
            overlap = check["overlap"]
            if overlap is None or competition_ok or overlap <= OVERLAP_LIMIT or round_number == MAX_ROUNDS - 1:
                break
            yield {"t": "status", "v": "Idea " + str(number) + " overlaps " + str(overlap) + "%. Narrowing it"}
            narrower = narrow_idea(llm, idea, summary, check["pages"])
            if not narrower:
                break
            idea = narrower
        finished.append({"idea": idea, "check": check})
    cards = []
    lines = []
    for number, item in enumerate(finished, 1):
        idea, check = item["idea"], item["check"]
        overlap = check["overlap"]
        within = overlap is not None and (competition_ok or overlap <= OVERLAP_LIMIT)
        cards.append({
            "name": idea["name"], "pitch": idea["pitch"], "audience": idea["audience"], "problem": idea["problem"], "overlap": overlap,
            "heavy": check["heavy"], "within_limit": within,
            "pages": [{"url": p["url"], "score": p["score"], "commercial": p["commercial"], "read_in_full": p["full"]} for p in check["pages"][:4]],
        })
        measured = "unverified, no usable web results" if overlap is None else str(overlap) + " percent measured from live pages"
        lines.append("Idea %d: %s. Pitch: %s. Audience: %s. Problem: %s. Method: %s. Overlap: %s. Within the limit: %s." % (number, idea["name"], idea["pitch"], idea["audience"], idea["problem"], idea["method"], measured, "yes" if within else "no"))
    yield {"t": "result", "v": {"competition_ok": competition_ok, "limit": OVERLAP_LIMIT, "ideas": cards, "date": datetime.date.today().isoformat()}}
    prompt = (
        "Present these three business ideas to the user as a warm peer. Use the overlap numbers exactly as given and never invent competitors or links. "
        "If an idea is not within the limit, say so honestly.\nUser profile: " + summary + "\n" + "\n".join(lines) + "\n"
        "For each idea write the name, the pitch, why it fits them, the overlap result and that it was measured by a live web search and page reading on " + datetime.date.today().isoformat() +
        ", and the Kerdos tiers: a Yearly plan at $100/year and a Premium Lifetime plan at $300, saying what the customer gets in each. " + TONE + " End without asking a question."
    )
    messages = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": prompt}]
    for piece in llm.stream(messages, max_tokens=1400):
        yield {"t": "token", "v": piece}


RD_SYS = "\n".join([
    "You are the Lead R&D Engineering Agent for Kerdos Business. Your sole objective is to analyze user behavior data, technical logs, and competitive intelligence to design micro-optimizations and macro-feature bundles.",
    "CRITICAL OPERATIONAL RULES:",
    "1. Do not write conversational filler, explanations, or questions.",
    "2. Output ONLY a valid JSON object matching the schema below.",
    "3. Every suggested feature or visual tweak must be backed by a specific data point found in the input. Quote the number and the field name. If the data does not support a suggestion, leave it out. If it supports nothing, return empty arrays and say why in limits.",
    "4. All code blocks or prompt updates inside the JSON must be fully functional and self-contained.",
    "Context: Kerdos Business is a hosted web app with an AI chat interviewer, a live web competition check, and premium tiers ($100/year and $300 lifetime). The data is server counts, timings, and error codes.",
    'Schema: {"agent": "Lead R&D Engineering Agent", "business_name": "Kerdos Business", "status": "ok", "micro_optimizations": [{"id": "M1", "title": "", "data_point": "field name and number", "change": "", "code": "self-contained code or prompt text", "expected_effect": ""}], "macro_feature_bundles": [{"id": "F1", "title": "", "data_points": ["field name and number"], "components": [""], "code_or_prompt": "self-contained code or prompt text"}], "limits": [""]}',
])
