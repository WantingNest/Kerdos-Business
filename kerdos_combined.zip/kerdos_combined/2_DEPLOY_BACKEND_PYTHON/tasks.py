import datetime
import json
import os

import engine

MIN_ANSWERS = int(os.environ.get("MIN_ANSWERS", "3"))
MAX_ANSWERS = int(os.environ.get("MAX_ANSWERS", "30"))
LIMIT = engine.OVERLAP_LIMIT
TOKENS = engine.MAX_TOKENS

INTERVIEW_RULES = "\n".join([
    "You are the AI Business Thinker for Kerdos. Your goal is to discover a tailored business idea, the user's target job role, and the industry genre, by interviewing them one step at a time.",
    "STRICT RULES:",
    "1. Ask exactly ONE question per turn, with one question mark.",
    "2. Never use pre-scripted, quiz-like, or fill-in-the-blank questions. Write every question fresh, in your own words, from the conversation so far. Different people and different runs must get different angles and follow-ups.",
    "3. Do not suggest business ideas during the interview. Uncover the user's job role, skills, or daily occupation; the genre (industry, market sector, or problem space) they want to target; real systemic problems they have seen; and a secondary interest or hobby that could be a creative spark.",
    "4. If an answer is vague or short, your next question must dig for specifics (platforms, mechanics, tools, situations).",
    "5. Before you finish you must also know roughly how many hours per week the user can spend and their starting budget. Ask for these organically, never as a form.",
    "6. You are fluent in internet slang and idioms. Interpret slang by its meaning, never as a literal product, business name, or asset. If the user names a habit like doom scrolling, your very next question must explore that behavioral ecosystem (attention algorithms, content curation, digital fatigue). If a term is truly ambiguous, never guess and never invent a value for it: fold a brief clarification into your single next question.",
    "7. Tone: you are a real-world strategic collaborator talking to a peer. Warm, intuitive, short active sentences. React to what they said before your question. No corporate AI fluff, no bullet lists.",
    "8. Set ready to true only when you know the job role or skills, the genre, a real problem, a secondary interest, weekly hours, and budget, and you understand the person well enough to invent ideas that truly fit them.",
    'Reply with ONLY a JSON object: {"intro": "one short warm sentence, only on the opening turn, otherwise empty", "question": "the single next question, empty when ready", "learned": ["up to 8 very short facts you know so far"], "ready": false}',
])

RD_SYS = "\n".join([
    "You are the Lead R&D Engineering Agent for Kerdos Business. Your sole objective is to analyze user behavior data, technical logs, and competitive intelligence to design micro-optimizations and macro-feature bundles.",
    "Do not wait to be told what to build. Brainstorm your own entirely new, creative feature ideas, visual micro-tweaks, and macro-feature bundles.",
    "CRITICAL OPERATIONAL RULES:",
    "1. Do not write conversational filler, explanations, or questions.",
    "2. Output ONLY a valid JSON object matching the schema below.",
    "3. Every item must be backed by specific evidence: either a number with its field name from the usage data (for example interview_funnel.turn_5 = 12), or a competitor observation that names the competitor URL or host from the competitor data. If the data does not support an item, leave it out. If it supports nothing, return empty arrays and say why in limits.",
    "4. All code or prompt text inside the JSON must be fully functional and self-contained: plain JavaScript or CSS for a single HTML page with no external libraries, or complete prompt text.",
    "5. content_pages are public research pages. Propose one only when the data holds real numbers worth reporting, never invent a statistic, never write thin or repetitive pages, and propose at most 2.",
    "Context: Kerdos Business is a hosted web app. A customer answers an AI interviewer one question at a time, then the server invents three business ideas, searches the live web, reads real competitor pages, and measures overlap. Customers get launch tools in a dropdown and can buy $10 monthly, $100 yearly, or $300 lifetime plans. The usage data is anonymous counts, timings, and error codes. The competitor data lists real pages, how often they changed, and new terms that appeared on them.",
    'Schema: {"agent": "Lead R&D Engineering Agent", "business_name": "Kerdos Business", "status": "ok", "feature_ideas": [{"id": "F1", "title": "", "evidence": "specific data point or competitor observation", "description": "", "code": "self-contained code or prompt text"}], "visual_micro_tweaks": [{"id": "V1", "title": "", "evidence": "", "change": "", "code": ""}], "macro_feature_bundles": [{"id": "B1", "title": "", "evidence": ["specific data point or competitor observation"], "components": [""], "code_or_prompt": ""}], "content_pages": [{"id": "C1", "title": "", "slug": "short-url-words", "evidence": "the real numbers from the input this page reports", "body": "3 to 6 short plain-text paragraphs using only numbers present in the input"}], "limits": [""]}',
])

TOOL_BRIEFS = {
    "val": "a 7-day validation plan for this idea: day-by-day actions, the questions to ask real buyers, and a clear pass-or-fail rule",
    "offer": "the first offer: the promise, what the $100 per year plan and the $300 lifetime plan each include, what makes it different, and how to launch it",
    "five": "a plan to land the first 5 customers: where to find them, the exact message to send, follow-ups, and what to track",
    "check": "a 30-day launch checklist in four weeks. Every task must be doable with the user's weekly hours, budget, and equipment limits",
    "mkt": "a 30-day marketing plan, week by week, using channels that fit the user's budget and hours, with a daily time block and numbers to track",
    "audit": "a daily target market audit routine: what to check each morning, which of the listed real competitor pages to watch, and how to react when they change",
    "pipe": "a custom prompt pipeline: four ready-to-paste prompts for an AI assistant, each tailored to this exact idea, plus the order to use them in",
}
PREMIUM_TOOLS = ("audit", "pipe")


def one_question(text):
    t = str(text or "").strip()
    i = t.find("?")
    if i >= 0 and t.find("?", i + 1) >= 0:
        t = t[: i + 1]
    return t


def clean_hist(hist):
    if not isinstance(hist, list) or len(hist) > MAX_ANSWERS:
        return None
    out = []
    for item in hist:
        if not isinstance(item, dict) or not isinstance(item.get("q"), str) or not isinstance(item.get("a"), str):
            return None
        if not item["a"].strip() or len(item["a"]) > 1500 or len(item["q"]) > 600:
            return None
        out.append({"q": item["q"].strip(), "a": item["a"].strip()})
    return out


def transcript(hist):
    if not hist:
        return "(no answers yet)"
    return "\n\n".join("Q%d: %s\nA%d: %s" % (i + 1, h["q"], i + 1, h["a"]) for i, h in enumerate(hist))[-9000:]


def interview_turn(llm, gate, hist, memory=""):
    known = ("\nThis is a returning user. What you already know from earlier sessions: " + memory[-1500:] + "\nDo not re-ask what you already know. Build on it and explore new angles.") if memory else ""
    opening = "" if hist else "\nThis is the opening turn: write a warm one-sentence intro, then ask question 1 about their primary skills, experience, or the kind of job role they gravitate toward."
    nudge = ""
    for _ in range(2):
        prompt = ("TASK:interview\n" + INTERVIEW_RULES + "\n\nCompetition answer: " + gate + "\nAnswers so far: " + str(len(hist)) + known + opening + nudge + "\n\nTranscript:\n" + transcript(hist) + "\n\nReturn only the JSON.")
        data = llm.json(prompt, max_tokens=TOKENS)
        if not data:
            continue
        learned = [str(x)[:80] for x in data.get("learned", [])][:8] if isinstance(data.get("learned"), list) else []
        ready = bool(data.get("ready")) or len(hist) >= MAX_ANSWERS
        if ready and len(hist) < MIN_ANSWERS:
            nudge = "\nYou are not done: you have only " + str(len(hist)) + " answers. Ask another question."
            continue
        if ready:
            return {"ready": True, "question": "", "intro": "", "learned": learned}
        question = one_question(data.get("question"))
        if question:
            return {"ready": False, "question": question, "intro": "" if hist else str(data.get("intro", ""))[:300], "learned": learned}
        nudge = "\nYou must ask exactly one question now."
    return None


def public_idea(idea, check, competition_ok):
    overlap = check["overlap"]
    within = overlap is not None and (competition_ok or overlap <= LIMIT)
    pages = check["pages"]
    matched = set()
    for p in pages:
        matched.update(p["matched"])
    gaps = [f["label"] for f in idea["features"] if f["label"] not in matched][:6]
    if overlap is None:
        note = "Unverified: the live web search returned nothing usable for this idea."
    else:
        note = "Measured overlap " + str(overlap) + "% by reading " + str(len(pages)) + " live pages on " + datetime.date.today().isoformat() + "."
        if pages:
            note += " Closest page: " + pages[0]["url"] + " (" + str(pages[0]["score"]) + "%)."
        if not within and not competition_ok:
            note += " This is above the " + str(LIMIT) + "% limit."
    return {
        "name": idea["name"], "pitch": idea["pitch"], "audience": idea["audience"], "problem": idea["problem"], "how": idea["method"],
        "jobRole": idea["jobRole"], "genre": idea["genre"], "whyFit": idea["whyFit"], "yearlyOffer": idea["yearlyOffer"], "lifetimeOffer": idea["lifetimeOffer"],
        "differentiator": idea["differentiator"], "sig": idea["sig"], "out": idea["out"], "format": idea["format"], "queries": idea["queries"], "features": idea["features"],
        "overlap": overlap, "heavy": check["heavy"], "within_limit": within, "note": note, "gaps": gaps,
        "pages": [{"url": p["url"], "score": p["score"], "commercial": p["commercial"], "full": p["full"], "title": p.get("title", "")} for p in pages[:5]],
    }


def draft(llm, gate_ok, hist, memory=""):
    earlier = ("\nEarlier sessions with this person (the new ideas must be clearly different from any ideas listed here): " + memory[-1500:]) if memory else ""
    rule = "The user is happy to enter a market that already has competition." if gate_ok else "Each idea must be narrow enough that real companies cover at most 10 percent of it."
    prompt = (
        "TASK:draft\nUsing the interview below, write exactly THREE completely novel business ideas that fit this specific person. " + rule + "\n"
        "Combine their job role or skills, their target genre, a real problem they described, and a secondary interest as a creative spark. Be fresh and specific, and never repeat a stock idea. Respect their weekly hours, budget, and equipment limits. Interpret slang by meaning, never as a product.\n"
        'Return ONLY JSON: {"profile": {"hobbies": "short summary of interests", "jobRole": "", "genre": "", "hours": "their time in plain words", "budget": "their budget in plain words", "gearText": "equipment limits or empty"}, "ideas": [' + engine.idea_schema() + "]}\n"
        "Give each idea exactly 10 distinctive features. Do not use generic words like app, platform, subscription, or service as keywords." + earlier + "\n\nInterview:\n" + transcript(hist)
    )
    for _ in range(2):
        data = llm.json(prompt, max_tokens=TOKENS * 2)
        if data and isinstance(data.get("ideas"), list):
            ideas = [engine.clean_idea(x) for x in data["ideas"] if isinstance(x, dict)]
            ideas = [x for x in ideas if x["name"]][:3]
            if ideas:
                profile = data.get("profile") if isinstance(data.get("profile"), dict) else {}
                return {k: str(profile.get(k, ""))[:200] for k in ("hobbies", "jobRole", "genre", "hours", "budget", "gearText")}, ideas
    return None


def narrow(llm, idea, profile, pages):
    closest = "; ".join(p["url"] + " (features found: " + ", ".join(p["matched"][:3]) + ")" for p in pages[:3])
    prompt = (
        "TASK:narrow\nThis business idea overlaps too much with real pages found on the web. Write ONE narrower, more specific idea that avoids what those pages already do and still fits the person.\n"
        "Person: " + json.dumps(profile) + "\nCurrent idea: " + json.dumps({k: idea[k] for k in ("name", "pitch", "audience", "problem", "method")}) + "\nClosest pages: " + closest + "\n"
        'Return ONLY JSON: {"idea": ' + engine.idea_schema() + "} with exactly 10 distinctive features."
    )
    data = llm.json(prompt, max_tokens=TOKENS)
    if data and isinstance(data.get("idea"), dict):
        new = engine.clean_idea(data["idea"])
        if new["name"]:
            return new
    return None


def ideas_pipeline(llm, gate, hist, record, memory=""):
    yield {"t": "status", "v": "Reading everything you told me"}
    gate_ok = gate == "Yes"
    drafted = draft(llm, gate_ok, hist, memory)
    if not drafted:
        yield {"t": "error", "v": "I could not invent ideas just now. Please try again."}
        return
    profile, ideas = drafted
    out = []
    for number, idea in enumerate(ideas, 1):
        check = None
        for round_number in range(engine.MAX_ROUNDS):
            yield {"t": "status", "v": "Idea " + str(number) + ": searching the live web for " + engine.clip(idea["name"], 40)}
            check = yield from engine.web_check(idea)
            record(check["pages"])
            overlap = check["overlap"]
            if overlap is None or gate_ok or overlap <= LIMIT or round_number == engine.MAX_ROUNDS - 1:
                break
            yield {"t": "status", "v": "Idea " + str(number) + " overlaps " + str(overlap) + "%, so I am narrowing it"}
            narrower = narrow(llm, idea, profile, check["pages"])
            if not narrower:
                break
            idea = narrower
        out.append(public_idea(idea, check, gate_ok))
    yield {"t": "result", "v": {"profile": profile, "competition_ok": gate_ok, "limit": LIMIT, "ideas": out}}


def drain(generator):
    try:
        while True:
            next(generator)
    except StopIteration as stop:
        return stop.value


def recheck(llm, gate, idea_raw, evidence, record):
    gate_ok = gate == "Yes"
    idea = engine.clean_idea(idea_raw)
    profile = {}
    check = drain(engine.web_check(idea))
    record(check["pages"])
    measured = check["overlap"]
    pages_text = "; ".join(p["url"] + " (" + str(p["score"]) + "% match, features: " + ", ".join(p["matched"][:3]) + ")" for p in check["pages"][:5]) or "none found"
    prompt = (
        "TASK:recheck\nYou are judging how much a business idea overlaps with real companies. Use ONLY the evidence below. Do not invent competitors.\n"
        "Idea: " + json.dumps({k: idea[k] for k in ("name", "pitch", "audience", "problem", "method")}) + "\nPages the server just read: " + pages_text + "\nMeasured overlap from those pages: " + str(measured) + "\n"
        "Extra findings pasted by the user (may be empty): " + (evidence[:3000] or "none") + "\n"
        "overlap_percent is your honest integer estimate of how much of the idea is already offered, using the pages and the pasted findings. Never go below the measured overlap.\n"
        'Return ONLY JSON: {"overlap_percent": 0, "closest": [{"name": "", "why": ""}], "reasoning": "one sentence"}'
    )
    data = llm.json(prompt, max_tokens=TOKENS) or {}
    try:
        judged = int(data.get("overlap_percent"))
    except (TypeError, ValueError):
        judged = measured
    final = max([v for v in (measured, judged) if v is not None] + [0]) if (measured is not None or judged is not None) else None
    shown = dict(check)
    shown["overlap"] = final
    result = {
        "idea": public_idea(idea, shown, gate_ok),
        "reasoning": str(data.get("reasoning", ""))[:400],
        "closest": [{"name": str(c.get("name", ""))[:80], "why": str(c.get("why", ""))[:160]} for c in data.get("closest", []) if isinstance(c, dict)][:5] if isinstance(data.get("closest"), list) else [],
        "pivot": None,
    }
    if not gate_ok and final is not None and final > LIMIT:
        narrower = narrow(llm, idea, profile, check["pages"])
        if narrower:
            second = drain(engine.web_check(narrower))
            record(second["pages"])
            result["pivot"] = public_idea(narrower, second, gate_ok)
    return result


def tool(llm, key, idea, profile, gate):
    pages = "; ".join(str(p.get("url", ""))[:120] for p in (idea.get("pages") or [])[:4] if isinstance(p, dict)) or "none listed"
    prompt = (
        "TASK:tool:" + key + "\nWrite " + TOOL_BRIEFS[key] + ".\n"
        "Idea: " + json.dumps({k: str(idea.get(k, ""))[:500] for k in ("name", "pitch", "audience", "problem", "how", "yearlyOffer", "lifetimeOffer", "differentiator")}) + "\n"
        "Person: " + json.dumps({k: str(profile.get(k, ""))[:200] for k in ("hobbies", "jobRole", "genre", "hours", "budget", "gearText")}) + "\n"
        "Real competitor pages found for this idea: " + pages + "\nCompetition answer: " + gate + ". Respect their time, budget, and equipment. Be specific to this exact idea, warm, and practical. Interpret slang by meaning.\n"
        'Return ONLY JSON: {"title": "", "intro": "one or two sentences", "sections": [{"heading": "", "text": "optional short paragraph", "bullets": ["concrete step or item"]}], "closing": "one sentence"}'
    )
    data = llm.json(prompt, max_tokens=TOKENS * 2)
    if not data or not isinstance(data.get("sections"), list):
        return None
    sections = []
    for s in data["sections"][:10]:
        if isinstance(s, dict):
            bullets = [str(b)[:400] for b in s.get("bullets", [])][:12] if isinstance(s.get("bullets"), list) else []
            sections.append({"heading": str(s.get("heading", ""))[:120], "text": str(s.get("text", ""))[:800], "bullets": bullets})
    return {"title": str(data.get("title", ""))[:160], "intro": str(data.get("intro", ""))[:500], "sections": sections, "closing": str(data.get("closing", ""))[:400]}


def memory_line(profile, ideas, learned):
    parts = []
    for key, label in (("jobRole", "job role"), ("genre", "genre"), ("hobbies", "interests"), ("hours", "time"), ("budget", "budget"), ("gearText", "equipment")):
        if profile.get(key):
            parts.append(label + ": " + str(profile[key])[:100])
    line = datetime.date.today().isoformat() + " | " + "; ".join(parts)
    if learned:
        line += " | learned: " + "; ".join(str(x)[:60] for x in learned[:6])
    if ideas:
        line += " | ideas suggested: " + ", ".join(str(i.get("name", ""))[:50] for i in ideas)
    return line


def merge_memory(old, line):
    lines = [x for x in (old or "").split("\n") if x.strip()]
    lines.append(line)
    return "\n".join(lines[-5:])
