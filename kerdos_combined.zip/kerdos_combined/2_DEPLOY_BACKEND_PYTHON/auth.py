import hashlib
import hmac
import json
import os
import re
import secrets
import smtplib
import ssl
import time
import urllib.request
from email.message import EmailMessage

import db

HARDCODED_SUPER_ADMIN = "willverwey@outlook.com"
SUPER_ADMIN_EMAILS = {HARDCODED_SUPER_ADMIN} | {e.strip().lower() for e in os.environ.get("SUPER_ADMIN_EMAILS", "").split(",") if e.strip()}
CODE_MINUTES = 10
MAX_ATTEMPTS = 5
SESSION_DAYS = 30
EMAIL_RE = re.compile(r"[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}")
APP_SECRET = (os.environ.get("APP_SECRET") or os.environ.get("PREMIUM_SECRET") or secrets.token_hex(24)).encode()
RESEND_URL = os.environ.get("RESEND_API_URL", "https://api.resend.com/emails")
BRAND = os.environ.get("BRAND_NAME", "Kerdos Business")


def normalize(email):
    value = str(email or "").strip().lower()
    if len(value) > 120 or not EMAIL_RE.fullmatch(value):
        return None
    return value


def is_super_admin(email):
    return email in SUPER_ADMIN_EMAILS


def hash_code(email, code):
    return hmac.new(APP_SECRET, (email + "|" + code).encode(), hashlib.sha256).hexdigest()


def hash_token(token):
    return hashlib.sha256(token.encode()).hexdigest()


def send_mail(to, subject, body):
    sender = os.environ.get("MAIL_FROM", "")
    resend_key = os.environ.get("RESEND_API_KEY", "")
    if resend_key and sender:
        payload = json.dumps({"from": sender, "to": [to], "subject": subject, "text": body}).encode()
        request = urllib.request.Request(RESEND_URL, data=payload, headers={"Authorization": "Bearer " + resend_key, "Content-Type": "application/json"}, method="POST")
        urllib.request.urlopen(request, timeout=15).close()
        return True
    host = os.environ.get("SMTP_HOST", "")
    if host and sender:
        message = EmailMessage()
        message["From"] = sender
        message["To"] = to
        message["Subject"] = subject
        message.set_content(body)
        port = int(os.environ.get("SMTP_PORT", "587"))
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            if os.environ.get("SMTP_STARTTLS", "1") == "1":
                smtp.starttls(context=ssl.create_default_context())
            if os.environ.get("SMTP_USER"):
                smtp.login(os.environ["SMTP_USER"], os.environ.get("SMTP_PASS", ""))
            smtp.send_message(message)
        return True
    return False


def request_code(email):
    code = "%06d" % secrets.randbelow(1000000)
    expires = int(time.time()) + CODE_MINUTES * 60
    db.execute("INSERT OR REPLACE INTO codes (email, code_hash, expires, attempts) VALUES (?, ?, ?, 0)", (email, hash_code(email, code), expires))
    body = "Your " + BRAND + " login code is " + code + ".\nIt works for " + str(CODE_MINUTES) + " minutes. If you did not ask for it, you can ignore this email."
    return send_mail(email, BRAND + " login code: " + code, body)


def verify_code(email, code):
    row = db.query("SELECT * FROM codes WHERE email = ?", (email,), one=True)
    if not row or row["expires"] < int(time.time()) or row["attempts"] >= MAX_ATTEMPTS:
        return False
    db.execute("UPDATE codes SET attempts = attempts + 1 WHERE email = ?", (email,))
    if not hmac.compare_digest(row["code_hash"], hash_code(email, str(code).strip())):
        return False
    db.execute("DELETE FROM codes WHERE email = ?", (email,))
    return True


def create_session(user_id):
    token = secrets.token_urlsafe(32)
    now = int(time.time())
    db.execute("INSERT INTO sessions (token_hash, user_id, created, expires) VALUES (?, ?, ?, ?)", (hash_token(token), user_id, now, now + SESSION_DAYS * 86400))
    return token


def user_from_token(token):
    if not token or len(token) > 100:
        return None
    row = db.query("SELECT user_id, expires FROM sessions WHERE token_hash = ?", (hash_token(token),), one=True)
    if not row or row["expires"] < int(time.time()):
        return None
    return db.get_user(row["user_id"])


def end_session(token):
    db.execute("DELETE FROM sessions WHERE token_hash = ?", (hash_token(token),))


def entitled(user):
    if user is None:
        return False
    if is_super_admin(user["email"]):
        return True
    if user["plan"] == "lifetime":
        return True
    if user["plan"] == "sprint":
        return bool(user.get("plan_expires")) and user["plan_expires"] > int(time.time())
    return user["plan"] in ("monthly", "annual") and user["plan_status"] in ("active", "trialing")
