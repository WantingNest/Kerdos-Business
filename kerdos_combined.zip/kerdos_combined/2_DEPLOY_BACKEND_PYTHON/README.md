# Kerdos Business: hosted AI Business Thinker

Same look and feel as the Kerdos website. The difference is the brain: everything now runs on a server.

- `/` the public homepage (who we are, calculator, demo, tabs for plans and pricing, footer), then login, then the AI interview, live-web idea check, dashboard, launch tools, and plans.
- `/admin` your approval queue, competitor list, and R&D controls. Needs `ADMIN_TOKEN`.
- Your AI key and every prompt live only on the server. The browser sends answers, never instructions.

## What the AI does

- **Interview:** the AI writes each question fresh from the conversation, one at a time. The AI decides when it knows enough. There is no fixed question list and no fixed question count. (Safety limits: at least `MIN_ANSWERS`, default 3, and at most `MAX_ANSWERS`, default 30.)
- **Ideas:** it invents three ideas, then searches the live web, reads real pages, and measures overlap. If you answered No to competition and an idea overlaps more than 10%, it narrows the idea and checks again.
- **Launch tools:** each dropdown answer is written by the AI for that exact idea. Two are Premium and need a plan token.
- **Competitor research:** every page found by an idea check is saved. A scheduled job re-reads the saved pages and records when they change and which new terms appear.
- **Autonomous R&D:** every `RD_AUTORUN_MINUTES` (default 360) the R&D agent reads usage numbers (interview drop-off, timings, errors, plan clicks), the uncovered-feature counts, and the competitor changes. It brainstorms new features, visual tweaks, and macro bundles. Each needs specific evidence or it is dropped.
- **Approval gate:** every R&D item is staged with a review window of `APPROVAL_WINDOW_SECONDS` (default 300, five minutes). A human must approve inside the window. After that it expires, and a later run can propose it again. Nothing is ever approved automatically. If `NOTIFY_WEBHOOK_URL` is set (Slack, Discord, or similar), the server pings it when something is staged.

## Run it on your own computer first

1. Install Python 3.10 or newer.
2. In this folder run: `pip install -r requirements.txt`
3. Set your settings (Windows Command Prompt):

       set LLM_PROVIDER=gemini
       set GEMINI_API_KEY=your-google-key
       set ADMIN_TOKEN=pick-a-long-random-string

4. Run: `python server.py`
5. Open http://localhost:8000 and http://localhost:8000/admin

Other AI backends: `LLM_PROVIDER=openai` with `OPENAI_API_KEY`, `LLM_PROVIDER=compatible` with `LLM_BASE_URL`, or `LLM_PROVIDER=ollama` for a local model. Set `LLM_MODEL` to a model your provider currently offers. The Gemini default (`gemini-2.0-flash`) may be retired, so check Google's list.

## Plans, limits, and growth features

These come from the Kerdos growth strategy. Every number is a setting you can change.

- **Free:** `FREE_IDEA_RUNS_PER_MONTH` (default 1) full idea run on a rolling 30-day basis. Each friend who joins from an invite link gives both people a bonus run, up to `REFERRAL_CAP` (default 5) per inviter.
- **Launch Sprint ($39 once):** 30 days of paid features with `SPRINT_RUNS` (default 10) idea runs. For people who will not subscribe. It ends by itself.
- **Monthly and Annual:** up to `PAID_RUNS_PER_MONTH` (default 60) idea runs. A fair-use cap that protects your AI bill. Annual is the featured plan.
- **Lifetime Founder Access ($300 once):** limited to the first `FOUNDING_LIMIT` (default 25) buyers and capped at `LIFETIME_RUNS_PER_MONTH` (default 30) runs, because the AI cost never stops. The pricing tab shows the spots left and turns the button to "Sold out".
- **Super-Admin:** no limits of any kind.
- **Share cards:** every idea has a "Share this idea" button that creates a public page at `/s/CODE` showing the idea, its measured overlap, and an invite link back to the site.
- **Partner codes:** in the admin page add a partner code. Anyone who signs up from `your-site/?ref=CODE` is counted for that partner, with a count of how many became paying users, so you can pay affiliates by hand. The app does not pay anyone for you.
- **Weekly competitor emails:** paid users can press "Watch competitors weekly" on an idea. The server re-reads those pages, and emails the user when one changes. It needs working email sending.
- **Research pages:** the R&D agent may propose a public research page built from your real numbers. It sits in the approval queue like everything else. When you approve it, it appears at `/reports`.
- **Cost panel:** the admin page counts AI calls and estimates cost per paying user and margin. Set `COST_PER_CALL_USD` to your real average cost, and `DAILY_CALL_ALERT` for a webhook alert when a day goes over.
- **Refund promise:** set `REFUND_DAYS` (for example 7) to show a refund line on the pricing tab. It is off by default. Only turn it on if you will honor it, and put the same terms in your refund policy page.

## Accounts, login, and the Super-Admin

- **Login is passwordless.** A visitor types an email, receives a 6-digit code (valid 10 minutes, five tries), and gets a session saved in the database. Signing up and logging in are the same step.
- **The whole AI side is locked.** `/api/interview`, `/api/ideas`, `/api/recheck`, and `/api/tool` return "please log in" without a valid session. The page also hides the interview, but the server is what enforces it.
- **Saved memory.** Each user's interview progress, past results, and a short memory summary are stored. A returning user can continue an interview, reopen past ideas, and the AI is told what it already knows. It is told to avoid repeating earlier ideas.
- **Super-Admin.** `willverwey@outlook.com` is written into `auth.py`. After that mailbox proves ownership with a login code, the account is treated as Super-Admin: no plan or idea-run limits, no rate limits, every Premium tool, and the admin page works from the login with no token. The email code is the key. Do not remove that step, or anyone could claim the address. Add more admins with `SUPER_ADMIN_EMAILS`. The approval queue still applies to R&D items; the bypass never skips the human gate.

## Sending login emails

The server needs a way to send mail, or nobody can log in.

- **Resend (simple):** create an account at resend.com, set `RESEND_API_KEY` and `MAIL_FROM`. Their sample sender may only deliver to your own address. To email customers you must verify your own domain. Check Resend's current rules.
- **SMTP:** set `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, and `MAIL_FROM`. Any normal mail provider works.
- If mail is not set up, the login form says it cannot send a code.

## Payments with Stripe

1. In Stripe, create four prices: Monthly $10 (recurring), Annual $100 (recurring), Lifetime $300 (one-time), and Launch Sprint $39 (one-time). Copy each price ID into `STRIPE_PRICE_MONTHLY`, `STRIPE_PRICE_ANNUAL`, `STRIPE_PRICE_LIFETIME`, `STRIPE_PRICE_SPRINT`.
2. Put your secret key in `STRIPE_SECRET_KEY` and your website address in `FRONTEND_URL`.
3. Add a webhook endpoint in Stripe pointing to `https://YOUR-BACKEND/api/stripe/webhook`. Enable these events: `checkout.session.completed`, `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.paid`, `invoice.payment_failed`. Copy its signing secret into `STRIPE_WEBHOOK_SECRET`.
4. The webhook updates each user's plan quietly in the database. Webhook calls are signature-checked and each event is applied once. A lifetime plan and a Sprint are never downgraded by a subscription event, and a Sprint expires by itself 30 days after purchase. A failed payment moves a subscriber to "past due", which turns off paid features until Stripe reports a successful payment.
5. Test with Stripe test keys first. The Super-Admin ignores all of this.

## Where the data lives

Users, sessions, saved interviews, results, and memory are in a SQLite file under `DATA_DIR`. The file survives restarts only if `DATA_DIR` is on a persistent disk. On free hosting that resets, every user and memory is lost on each restart. Use a host with a disk (for example a paid Render plan with a disk mounted at `/var/data`). For many users, move the data layer to a hosted Postgres database such as Supabase. `db.py` is the only file that talks to the database.

## Two ways to put it on the internet

**Easiest: one place.** Host this whole folder on a Python host such as Render. It serves the website at `/` and the admin page at `/admin` by itself. Nothing else is needed.

**Website on Netlify, brain on Render.** Netlify only hosts static files, so it cannot run `server.py`. Put the folder `1_DEPLOY_FRONTEND_NETLIFY` on Netlify and this folder on Render, then connect them:

1. Deploy this folder to Render (steps below). Set `ALLOWED_ORIGINS` to your Netlify address, for example `https://your-site.netlify.app`.
2. In the Netlify folder, open `config.js` and set `window.KERDOS_API` to your Render address.
3. Drag the Netlify folder (the folder itself) into Netlify Drop. `index.html` must sit at the top level of what you drop.
4. Open `https://your-render-address/healthz`. It should show `{"ok": true}`. If your Netlify site shows a yellow "not connected" notice, `config.js` or `ALLOWED_ORIGINS` is wrong.

The admin page always lives on the Render address (`/admin`), never on Netlify.

## Render steps

(details)

1. Put this folder in a GitHub repository.
2. On render.com create a new Web Service from it.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn -w 1 --threads 8 --timeout 600 -b 0.0.0.0:$PORT server:app` (one worker only: the scheduler, rate limits, and files live in that process). The included `render.yaml` already has this.
5. Add the environment variables from `.env.example`, including `ALLOWED_ORIGINS` if your website is on Netlify.
6. Add a persistent disk (a paid Render feature) and set `DATA_DIR` to its path. On the free plan the server sleeps when idle and its saved data resets on restart or redeploy.
7. Your host provides https. Point your own domain at it if you like.

## Limits and costs you still control

- Visitors are rate limited per person: `INTERVIEW_PER_MINUTE` (40), `IDEAS_PER_HOUR` (10), `RECHECK_PER_HOUR` (20), `TOOL_PER_HOUR` (60). These protect your AI bill and are not a credit system for customers. Set any of them to 0 to turn that limit off, but then one visitor can run up your bill.
- Reply length limit is `LLM_MAX_TOKENS` (default 2048).
- Every interview turn, idea check, tool answer, and R&D run is a paid or free-tier call to your AI provider. The R&D agent runs by itself on schedule, so it uses calls even when nobody is online. Set `RD_AUTORUN_MINUTES=0` to turn that off.

## Security notes

- Clients cannot send system instructions or choose a task freely. Each endpoint has a fixed task and size limits.
- The page reader blocks private and internal addresses and re-checks every redirect. Never set `ALLOW_PRIVATE_FETCH=1` on a public server. It exists only for testing.
- Admin endpoints need `ADMIN_TOKEN` and are off without it.
- Premium tools check a signed token from the test checkout. The checkout is TEST MODE only: typing 4242 as the card unlocks it, and no money moves. Replace it with a real payment provider (for example Stripe) before charging anyone.
- Add a privacy notice. Customers' answers go to your AI provider, and the server keeps anonymous counts, timings, and short idea-feature labels for the R&D agent.

## Known limits

- Search uses DuckDuckGo through the `ddgs` library. Cloud servers are sometimes blocked or limited. If the check says "unverified", switch to a paid search API.
- Competitor monitoring only tracks pages the idea checks have found. It does not crawl whole sites, app stores, or social media.
- Overlap is keyword matching on real pages. It is strong evidence, not proof.
- No accounts or database. Files in `DATA_DIR` hold everything.

## Running with Docker

A `Dockerfile` is included for any host that runs containers (Fly.io, Railway, a VPS):

    docker build -t kerdos .
    docker run -p 8080:8080 -v kerdos_data:/data --env-file .env kerdos

Mount a volume at `/data` so users and plans survive restarts. Set `ALLOWED_ORIGINS` and `FRONTEND_URL` to your Cloudflare Pages address (for example `https://your-project.pages.dev`, no slash at the end).
