import base64
import hashlib
import hmac
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

import db

TIERS = {"monthly": "STRIPE_PRICE_MONTHLY", "annual": "STRIPE_PRICE_ANNUAL", "lifetime": "STRIPE_PRICE_LIFETIME", "sprint": "STRIPE_PRICE_SPRINT"}
SPRINT_DAYS = 30
TOLERANCE = 300


def configured():
    return bool(os.environ.get("STRIPE_SECRET_KEY"))


def price_for(tier):
    return os.environ.get(TIERS.get(tier, ""), "")


def tier_for_price(price_id):
    for tier, env in TIERS.items():
        if price_id and os.environ.get(env) == price_id:
            return tier
    return None


def stripe_post(path, fields):
    request = urllib.request.Request("https://api.stripe.com/v1/" + path, data=urllib.parse.urlencode(fields).encode(), method="POST")
    token = base64.b64encode((os.environ["STRIPE_SECRET_KEY"] + ":").encode()).decode()
    request.add_header("Authorization", "Basic " + token)
    with urllib.request.urlopen(request, timeout=20) as response:
        return json.loads(response.read().decode())


def create_checkout(user, tier, return_base):
    price = price_for(tier)
    if not price:
        raise ValueError("That plan is not set up yet.")
    fields = {
        "mode": "payment" if tier in ("lifetime", "sprint") else "subscription",
        "line_items[0][price]": price, "line_items[0][quantity]": "1",
        "success_url": return_base + "?paid=1", "cancel_url": return_base + "?canceled=1",
        "client_reference_id": str(user["id"]), "metadata[plan]": tier, "metadata[user_id]": str(user["id"]),
    }
    if user.get("stripe_customer"):
        fields["customer"] = user["stripe_customer"]
    else:
        fields["customer_email"] = user["email"]
    if tier not in ("lifetime", "sprint"):
        fields["subscription_data[metadata][plan]"] = tier
        fields["subscription_data[metadata][user_id]"] = str(user["id"])
    return stripe_post("checkout/sessions", fields)["url"]


def verify_signature(payload, header, secret, now=None):
    if not secret or not header:
        return False
    parts = {}
    for item in header.split(","):
        key, _, value = item.partition("=")
        parts.setdefault(key.strip(), []).append(value.strip())
    try:
        stamp = int(parts.get("t", ["0"])[0])
    except ValueError:
        return False
    if abs((now or time.time()) - stamp) > TOLERANCE:
        return False
    expected = hmac.new(secret.encode(), (str(stamp) + ".").encode() + payload, hashlib.sha256).hexdigest()
    return any(hmac.compare_digest(expected, sig) for sig in parts.get("v1", []))


def set_plan(user_id, plan, status, customer=None, subscription=None, expires=None):
    now = int(time.time())
    db.execute(
        "UPDATE users SET plan = ?, plan_status = ?, stripe_customer = COALESCE(?, stripe_customer), stripe_subscription = COALESCE(?, stripe_subscription), plan_updated = ?, plan_expires = ? WHERE id = ?",
        (plan, status, customer, subscription, now, expires, user_id),
    )


def sprint_expiry():
    return int(time.time()) + SPRINT_DAYS * 86400


def find_user(obj):
    meta = obj.get("metadata") or {}
    uid = obj.get("client_reference_id") or meta.get("user_id")
    if uid and str(uid).isdigit():
        user = db.get_user(int(uid))
        if user:
            return user
    if obj.get("subscription") or obj.get("id", "").startswith("sub_"):
        sub = obj.get("subscription") if isinstance(obj.get("subscription"), str) else obj.get("id")
        row = db.query("SELECT * FROM users WHERE stripe_subscription = ?", (sub,), one=True)
        if row:
            return row
    if obj.get("customer"):
        return db.query("SELECT * FROM users WHERE stripe_customer = ?", (obj["customer"],), one=True)
    return None


def apply_event(event):
    event_id = str(event.get("id", ""))
    if not event_id or db.query("SELECT id FROM stripe_events WHERE id = ?", (event_id,), one=True):
        return "duplicate"
    db.execute("INSERT INTO stripe_events (id, created) VALUES (?, ?)", (event_id, int(time.time())))
    kind = event.get("type", "")
    obj = (event.get("data") or {}).get("object") or {}
    user = find_user(obj)
    if user is None:
        return "no user"
    if kind == "checkout.session.completed":
        plan = (obj.get("metadata") or {}).get("plan")
        if plan in TIERS and obj.get("payment_status") in ("paid", "no_payment_required"):
            if plan == "sprint":
                if user["plan"] == "lifetime" or user["plan_status"] in ("active", "trialing") and user["plan"] in ("monthly", "annual"):
                    return "sprint ignored: already has a better plan"
                set_plan(user["id"], "sprint", "active", obj.get("customer"), None, sprint_expiry())
                return "sprint set"
            status = "lifetime" if plan == "lifetime" else "active"
            set_plan(user["id"], plan, status, obj.get("customer"), obj.get("subscription"))
            return "plan set"
        return "ignored"
    if kind in ("customer.subscription.updated", "customer.subscription.created"):
        if user["plan"] in ("lifetime", "sprint"):
            return "plan kept"
        items = ((obj.get("items") or {}).get("data")) or []
        price_id = ((items[0] or {}).get("price") or {}).get("id") if items else None
        plan = (obj.get("metadata") or {}).get("plan") or tier_for_price(price_id) or user["plan"]
        status = obj.get("status", "none")
        if status in ("canceled", "unpaid", "incomplete_expired"):
            set_plan(user["id"], "free", "none", obj.get("customer"), obj.get("id"))
        elif plan in ("monthly", "annual"):
            set_plan(user["id"], plan, status, obj.get("customer"), obj.get("id"))
        return "subscription updated"
    if kind == "customer.subscription.deleted":
        if user["plan"] in ("monthly", "annual"):
            set_plan(user["id"], "free", "none", obj.get("customer"), obj.get("id"))
        return "subscription ended"
    if kind == "invoice.payment_failed":
        if user["plan"] in ("monthly", "annual"):
            set_plan(user["id"], user["plan"], "past_due")
        return "payment failed"
    if kind == "invoice.paid":
        if user["plan"] in ("monthly", "annual"):
            set_plan(user["id"], user["plan"], "active")
        return "invoice paid"
    return "ignored"
