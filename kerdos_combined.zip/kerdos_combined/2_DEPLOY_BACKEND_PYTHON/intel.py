import json
import os
import threading
import time
import urllib.parse

import engine

DATA_DIR = os.environ.get("DATA_DIR", "data")
FILE = os.path.join(DATA_DIR, "competitors.json")
WATCH_HOURS = float(os.environ.get("WATCH_HOURS", "12"))
lock = threading.Lock()


def load():
    try:
        with open(FILE, encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return {}


def save(data):
    with open(FILE, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=1)


def record(pages):
    now = int(time.time())
    with lock:
        data = load()
        for p in pages:
            if p["score"] < 1:
                continue
            item = data.get(p["url"]) or {"host": urllib.parse.urlparse(p["url"]).netloc.replace("www.", ""), "first_seen": now, "seen_count": 0, "change_count": 0, "last_added_terms": [], "terms": []}
            item.update({"title": p.get("title", ""), "last_seen": now, "last_checked": item.get("last_checked", now), "hash": p.get("hash", item.get("hash", "")), "excerpt": p.get("excerpt", ""), "score_max": max(p["score"], item.get("score_max", 0)), "commercial": p["commercial"]})
            item["seen_count"] += 1
            if p.get("terms"):
                item["terms"] = p["terms"]
            data[p["url"]] = item
        if len(data) > 400:
            keep = sorted(data.items(), key=lambda kv: kv[1].get("last_seen", 0), reverse=True)[:400]
            data = dict(keep)
        save(data)


def watch(limit=12):
    now = int(time.time())
    with lock:
        data = load()
    due = [u for u, i in data.items() if now - i.get("last_checked", 0) >= WATCH_HOURS * 3600]
    due.sort(key=lambda u: data[u].get("score_max", 0), reverse=True)
    changed = []
    for url in due[:limit]:
        page = engine.fetch_page(url)
        item = data[url]
        item["last_checked"] = now
        if page and len(page["text"]) > 200:
            text = page["text"].lower()
            new_hash = engine.hashlib.sha1(text.encode("utf-8", errors="ignore")).hexdigest()[:12]
            if item.get("hash") and new_hash != item["hash"]:
                terms = engine.top_terms(text)
                added = sorted(set(terms) - set(item.get("terms", [])))[:12]
                item["change_count"] = item.get("change_count", 0) + 1
                item["changed_at"] = now
                item["last_added_terms"] = added
                item["terms"] = terms
                changed.append(url)
            item["hash"] = new_hash
            item["excerpt"] = page["text"][:240]
        time.sleep(0.3)
    with lock:
        merged = load()
        merged.update(data)
        save(merged)
    return changed


def summary():
    data = load()
    ranked = sorted(data.items(), key=lambda kv: kv[1].get("score_max", 0), reverse=True)[:12]
    return {
        "tracked_pages": len(data),
        "pages_changed_at_least_once": len([1 for i in data.values() if i.get("change_count", 0) > 0]),
        "top_competitors": [{"url": u, "host": i["host"], "title": i.get("title", ""), "best_overlap_score": i.get("score_max", 0), "times_seen": i.get("seen_count", 0), "times_changed": i.get("change_count", 0), "new_terms_after_last_change": i.get("last_added_terms", [])[:8], "product_like": i.get("commercial", False)} for u, i in ranked],
    }


def ensure(urls):
    now = int(time.time())
    with lock:
        data = load()
        for url in urls:
            if url not in data:
                data[url] = {"host": urllib.parse.urlparse(url).netloc.replace("www.", ""), "first_seen": now, "last_seen": now, "seen_count": 0, "change_count": 0,
                             "last_added_terms": [], "terms": [], "hash": "", "last_checked": 0, "score_max": 1, "commercial": False, "title": "", "excerpt": ""}
        save(data)
