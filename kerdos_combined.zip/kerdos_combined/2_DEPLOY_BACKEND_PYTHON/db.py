import json
import os
import sqlite3
import threading
import time

DATA_DIR = os.environ.get("DATA_DIR", "data")
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(DATA_DIR, "kerdos.db"))
lock = threading.Lock()

SCHEMA = [
    """CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE NOT NULL, created INTEGER NOT NULL, last_login INTEGER,
        plan TEXT NOT NULL DEFAULT 'free', plan_status TEXT NOT NULL DEFAULT 'none', stripe_customer TEXT, stripe_subscription TEXT,
        plan_updated INTEGER, memory TEXT NOT NULL DEFAULT '')""",
    "CREATE TABLE IF NOT EXISTS codes (email TEXT PRIMARY KEY, code_hash TEXT NOT NULL, expires INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0)",
    "CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created INTEGER NOT NULL, expires INTEGER NOT NULL)",
    "CREATE TABLE IF NOT EXISTS interviews (user_id INTEGER PRIMARY KEY, gate TEXT, hist TEXT NOT NULL, question TEXT, intro TEXT, learned TEXT, updated INTEGER NOT NULL)",
    "CREATE TABLE IF NOT EXISTS results (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, created INTEGER NOT NULL, gate TEXT, profile TEXT NOT NULL, ideas TEXT NOT NULL)",
    "CREATE TABLE IF NOT EXISTS stripe_events (id TEXT PRIMARY KEY, created INTEGER NOT NULL)",
    "CREATE TABLE IF NOT EXISTS shares (token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, idea TEXT NOT NULL, created INTEGER NOT NULL)",
    "CREATE TABLE IF NOT EXISTS watches (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, name TEXT NOT NULL, urls TEXT NOT NULL, created INTEGER NOT NULL, last_digest INTEGER NOT NULL)",
    "CREATE TABLE IF NOT EXISTS partners (code TEXT PRIMARY KEY, name TEXT NOT NULL, created INTEGER NOT NULL)",
]
NEW_USER_COLUMNS = [("plan_expires", "INTEGER"), ("bonus_runs", "INTEGER NOT NULL DEFAULT 0"), ("ref_code", "TEXT"), ("partner", "TEXT"), ("referred_by", "INTEGER")]


def connect():
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init():
    with lock:
        conn = connect()
        try:
            for statement in SCHEMA:
                conn.execute(statement)
            have = {row["name"] for row in conn.execute("PRAGMA table_info(users)").fetchall()}
            for name, kind in NEW_USER_COLUMNS:
                if name not in have:
                    conn.execute("ALTER TABLE users ADD COLUMN " + name + " " + kind)
            conn.commit()
        finally:
            conn.close()


def query(sql, params=(), one=False):
    with lock:
        conn = connect()
        try:
            rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
        finally:
            conn.close()
    if one:
        return rows[0] if rows else None
    return rows


def execute(sql, params=()):
    with lock:
        conn = connect()
        try:
            cursor = conn.execute(sql, params)
            conn.commit()
            return cursor.lastrowid
        finally:
            conn.close()


def get_user(user_id):
    return query("SELECT * FROM users WHERE id = ?", (user_id,), one=True)


def user_by_email(email):
    return query("SELECT * FROM users WHERE email = ?", (email,), one=True)


def get_or_create_user(email):
    now = int(time.time())
    execute("INSERT OR IGNORE INTO users (email, created) VALUES (?, ?)", (email, now))
    execute("UPDATE users SET last_login = ? WHERE email = ?", (now, email))
    return user_by_email(email)


def save_interview(user_id, gate, hist, question, intro, learned):
    execute(
        "INSERT OR REPLACE INTO interviews (user_id, gate, hist, question, intro, learned, updated) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (user_id, gate, json.dumps(hist), question, intro, json.dumps(learned), int(time.time())),
    )


def load_interview(user_id):
    row = query("SELECT * FROM interviews WHERE user_id = ?", (user_id,), one=True)
    if not row:
        return None
    return {"gate": row["gate"], "hist": json.loads(row["hist"]), "question": row["question"] or "", "intro": row["intro"] or "", "learned": json.loads(row["learned"] or "[]")}


def clear_interview(user_id):
    execute("DELETE FROM interviews WHERE user_id = ?", (user_id,))


def save_result(user_id, gate, profile, ideas):
    return execute("INSERT INTO results (user_id, created, gate, profile, ideas) VALUES (?, ?, ?, ?, ?)", (user_id, int(time.time()), gate, json.dumps(profile), json.dumps(ideas)))


def count_results_since(user_id, since):
    row = query("SELECT COUNT(*) AS n FROM results WHERE user_id = ? AND created >= ?", (user_id, since), one=True)
    return row["n"] if row else 0


def list_results(user_id, limit=20):
    rows = query("SELECT id, created, ideas FROM results WHERE user_id = ? ORDER BY id DESC LIMIT ?", (user_id, limit))
    return [{"id": r["id"], "created": r["created"], "ideas": [{"name": i.get("name", ""), "overlap": i.get("overlap"), "pitch": i.get("pitch", "")} for i in json.loads(r["ideas"])]} for r in rows]


def get_result(user_id, result_id):
    row = query("SELECT * FROM results WHERE id = ? AND user_id = ?", (result_id, user_id), one=True)
    if not row:
        return None
    return {"id": row["id"], "created": row["created"], "gate": row["gate"], "profile": json.loads(row["profile"]), "ideas": json.loads(row["ideas"])}


def set_memory(user_id, text):
    execute("UPDATE users SET memory = ? WHERE id = ?", (text[-3000:], user_id))


def ensure_ref_code(user):
    if user.get("ref_code"):
        return user["ref_code"]
    import secrets
    for _ in range(10):
        code = secrets.token_hex(4)
        if not query("SELECT id FROM users WHERE ref_code = ?", (code,), one=True):
            execute("UPDATE users SET ref_code = ? WHERE id = ?", (code, user["id"]))
            return code
    return ""


def user_by_ref(code):
    return query("SELECT * FROM users WHERE ref_code = ?", (code,), one=True)


def referral_count(user_id):
    return query("SELECT COUNT(*) AS n FROM users WHERE referred_by = ?", (user_id,), one=True)["n"]


def add_bonus(user_id, amount):
    execute("UPDATE users SET bonus_runs = MAX(0, bonus_runs + ?) WHERE id = ?", (amount, user_id))


def count_lifetime():
    return query("SELECT COUNT(*) AS n FROM users WHERE plan = 'lifetime'", one=True)["n"]
