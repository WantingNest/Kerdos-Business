window.KERDOS_API = "";
