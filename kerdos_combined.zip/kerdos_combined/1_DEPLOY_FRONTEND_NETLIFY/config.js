window.KERDOS_API = "https://PUT-YOUR-BACKEND-ADDRESS-HERE.onrender.com";
