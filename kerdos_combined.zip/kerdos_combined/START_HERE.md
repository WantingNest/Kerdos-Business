# Kerdos Business: deploy guide

## What this version does

- **Public homepage:** "Stop guessing what to start." Who we are, a comparison with chatbots and consultants, a savings calculator, a looping demo, metric dials, tabs for Overview, How it works, and Plans / Pricing, and a full footer.
- **Mandatory login:** nobody can open or use the interview without logging in with a one-time email code. The server enforces it, not just the page.
- **Saved memory:** progress, past ideas, and a summary of what the AI learned are saved per user, so the AI remembers returning users and avoids repeating itself.
- **Plans:** Free (1 idea run a month, plus bonus runs from invites), Launch Sprint ($39 once, 30 days), Monthly ($10), Annual ($100, the featured plan), and Lifetime ($300, limited to 25 founding members with a monthly run cap).
- **Growth features:** invite links that give both people a bonus run, public share pages for each idea, partner codes you can track and pay by hand, weekly competitor-change emails for paid users, approved research pages at `/reports`, and an admin panel with AI cost, margin, and partner numbers.
- **Super-Admin:** `willverwey@outlook.com` is built in. After you confirm that mailbox with a login code, that account skips every limit and payment gate and opens the admin page automatically.
- **Stripe hooks:** webhooks quietly update each user's plan. Secrets live only in environment settings.

## Two things to know first

1. The Super-Admin bypass only works after the email code is entered. That code proves the mailbox is yours. Without it, anyone could type your address and become admin.
2. User data lives in a database file. On a free host with no disk it is erased on every restart. Use a host with a persistent disk before you take real customers.

## Do these in order

**Step 1. Backend (the brain, accounts, payments)**
1. Put the folder `2_DEPLOY_BACKEND_PYTHON` in a GitHub repository. Do not add a `.env` file.
2. On render.com create a Blueprint from it (it reads `render.yaml`), or a Web Service with the commands in that folder's README.
3. Fill in the settings listed in `.env.example`. The must-haves are `GEMINI_API_KEY`, `ALLOWED_ORIGINS` (your Cloudflare Pages or Netlify address, no slash at the end), `FRONTEND_URL` (the same address), `MAIL_FROM` plus a way to send mail (`RESEND_API_KEY` or `SMTP_*`).
4. Open `https://YOUR-BACKEND/healthz`. You should see `{"ok": true}`.
5. For payments, follow "Payments with Stripe" in that README (four prices, one webhook). Until then, plan buttons say "Payments are not set up yet." To try the fake card 4242 while testing, set `ALLOW_TEST_CHECKOUT=1`, and turn it off before launch.

**Step 2. Website on Cloudflare Pages (Netlify also works)**
1. Open `1_DEPLOY_FRONTEND_NETLIFY/config.js` and replace the placeholder with your backend address.
2. Cloudflare: open dash.cloudflare.com, go to Workers & Pages, choose Create, then Pages, then Upload assets. Name the project, then drag in the folder `1_DEPLOY_FRONTEND_NETLIFY` (the folder itself, with `index.html` at its top level) and press Deploy. (Netlify Drop also works with the same folder.)
3. Open your `*.pages.dev` address. You should see the homepage. A yellow notice means the backend is not connected: re-check `config.js`, and make sure `ALLOWED_ORIGINS` and `FRONTEND_URL` on the backend are exactly your `https://YOUR-PROJECT.pages.dev` address with no slash at the end. If you add a custom domain later, put that address there instead and redeploy the backend settings.
4. `/preview.html` on the same address is the sample-data preview. Log in there with any email and any 6 digits.
5. Replace the placeholder pages `privacy.html`, `terms.html`, and `refunds.html` with real policies.

**Step 3. Log in as admin**
Go to your site, log in with `willverwey@outlook.com`, type the code from your inbox, then open `https://YOUR-BACKEND/admin`. It opens automatically with that login.

## Cloudflare notes

- Cloudflare Pages hosts only the website folder. The accounts, AI and payments backend must run on a Python host (Render, Railway, Fly.io, or any server that can run the included `Dockerfile`). Cloudflare Workers cannot run this backend as written.
- The folder includes `_headers` (security headers) and `404.html`. The old `_redirects` file was removed because Pages already serves `/admin` from `admin.html`, which forwards to your backend admin page.
- Re-upload the folder in Pages whenever you change `config.js`.

## Decisions that are yours

- **Lifetime plan:** it is capped on purpose, because the AI cost never stops. Change the numbers with `FOUNDING_LIMIT` and `LIFETIME_RUNS_PER_MONTH`.
- **Refund promise:** hidden by default. Set `REFUND_DAYS` only if you will honor it, and write the same terms into `refunds.html`.
- **Partner payouts:** the app counts signups and paying users per partner code. You pay partners yourself.
- **Run caps:** the 60-a-month cap on paid plans is a fair-use guard. Change `PAID_RUNS_PER_MONTH` if your real costs allow more.

## Honest notes

- Tested with stand-in AI, email, search, and Stripe messages, plus a browser simulator. Not tested with real Gemini, a real email provider, a real Stripe account, or a live Cloudflare or Render deployment.
- Render's free plan sleeps when idle and has no disk, so saved users and scheduled jobs are unreliable on it.
- Resend's sample sender may only deliver to your own address until you verify a domain.
- The overlap number is keyword matching on real pages. It is evidence, not proof, and the site says so.
- A session token is kept in the browser. Keep the site free of third-party scripts.

## The other folders

- `3_local_scripts`: terminal versions for your own PC with Ollama.
- `4_private_browser_ai`: an AI that runs inside the browser, for private personal use.
- `5_earlier_versions`: older single-file versions, for reference.
